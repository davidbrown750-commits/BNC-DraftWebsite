4000 Series GUI - Zip Installer
================================

This package replaces the old IExpress self-extracting installer.

How to install:

1. Extract the entire zip folder.
2. Double-click:

   Install_4000_Series_GUI.cmd

3. The script installs the app to:

   %LOCALAPPDATA%\Berkeley Nucleonics\4000 Series GUI

4. It creates:

   - a Desktop shortcut
   - a Start Menu shortcut
   - a Start Menu uninstall shortcut

Important:

Do not run the installer directly from inside the zip preview window.
Right-click the zip, choose Extract All, then run Install_4000_Series_GUI.cmd from the extracted folder.

Included files:

- 4000 Series GUI.exe
- bnc_transparent.ico
- Install_4000_Series_GUI.cmd
- WINDOWS_INSTALLER_ZIP_README.txt
