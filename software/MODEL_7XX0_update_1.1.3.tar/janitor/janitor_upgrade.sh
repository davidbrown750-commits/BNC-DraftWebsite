#!/bin/sh

# legacy janitor deletes the update package, so we restore it here if possible.

# The problem is that by unpacking the entire tar we might have exceeded the 
# flash storage on the device. i.e. some selection of files may be missing.
# We can check for ok taskit payload and updater if a valid md5 hash is provided. 
# Everything else we don't care about, as it is not needed on taskit.

if ! $(tail -n 2 $0 | grep "# ~~ last line verification ~~" > /dev/null)
then
        echo "$0 is corrupted (incomplete)"
        exit 1
fi

need_rerun=0

homedir="/root"


janitor_md5=$(cat "./janitor_md5" | cut -d ' ' -f1)
if [ ${#janitor_md5} -eq 32 ]
then
    working_sum=$(md5sum "./janitor.sh" | cut -d ' ' -f1)
    if [ $working_sum != $janitor_md5 ] || [ ! -f "./janitor.sh" ]
    then
        echo "janitor broken - package unusable."
        exit 2
    fi
else
    echo "janitor checksum broken - package unusable."
    exit 2
fi

# replace janitor if ok
chown root janitor.sh
chmod +x janitor.sh
cp janitor.sh /root/janitor.sh


if grep -q -e "Zynq" /proc/cpuinfo
then
    # do not expect to run out of flash on Zynq. 
    # just re-pack everything and terminate.
    # mv updater_soc updater
    # mv payload_soc payload
    tar -cvf "schoggibroedli.tar" *
    mv "schoggibroedli.tar" "$homedir/schoggibroedli.tar"
    # cd "$homedir"
    # rm -rf ./temp
    echo "Zynq updater package restored."

    exit 0
fi

# armcont is already running armcont_janitor, but CONT1 will need to execute this
rm janitor.sh


# first check if md5 hash of expected length even exists -> prevent matching of zeros
payload_md5=$(cat "./payload_md5" | cut -d ' ' -f1)
if [ ${#payload_md5} -eq 32 ]
then
    working_sum=$(md5sum "./payload" | cut -d ' ' -f1)
    if [ $working_sum != $payload_md5 ] || [ ! -f "./payload" ]
    then
        echo "payload broken"
        need_rerun=1
    fi
else
    echo "payload checksum broken"
    need_rerun=1
fi

updater_md5=$(cat "./updater_md5" | cut -d ' ' -f1)
if [ ${#updater_md5} -eq 32 ]
then
    working_sum=$(md5sum "./updater" | cut -d ' ' -f1)
    if [ $working_sum != $updater_md5 ] || [ ! -f "./updater" ]
    then
        echo "updater broken"
        need_rerun=1
    fi
else
    echo "updater checksum broken"
    need_rerun=1
fi



if [ $need_rerun -ne 0 ]
then
    # payload was damaged => cannot continue. 
    # This script has by now however replaced the old janitor
    # -> trust in ./janitor/armcont_janitor.sh to perform update without issue next time.
    echo "update package got damaged from out of storage; need to re-run upgrade."
    cd "$homedir"
    rm -rf ./temp
    exit $need_rerun
fi

# # if payload was not damaged: re-pack update as new janitor expects it
# if payload was not damaged: re-pack update, cleanup temp/, restore needed
tar -cvf "schoggibroedli.tar" payload updater packageinfo matching.txt
if [ $? == 0 ]
then
    mv "schoggibroedli.tar" "$homedir/schoggibroedli.tar"
    cd "$homedir"
    # rm -rf ./*

    # tar -xf "$homedir/schoggibroedli.tar"
    # rm "$homedir/schoggibroedli.tar"

    echo "successfully restored update package."
    exit 0

else 
    echo "restoring update package failed; need to re-run upgrade."
    cd "$homedir"
    rm -rf ./temp
    exit 1
fi

# notes from when it was integrated in janitor:
# # provide itself as new janitor script
# cd $HOME/temp/
# cp "$0" $HOME/janitor_new.sh

# # re-pack update as new janitor expects it
# tar -xf "schoggibroedli.tar" ./*
# mv "schoggibroedli.tar" "$HOME/schoggibroedli.tar"
# cd $HOME
# rm -rf ./temp

# # call itself as new janitor script
# ./janitor_new.sh

# # overwrite old janitor with self if it completed successfully
# if [ $? == 0 ]
# then 
#     mv janitor_new.sh  janitor.sh
#     echo "transitional update successful."
#     echo "todo: reboot"
#     echo "todo: remove schoggibroedli"
#     # shutdown -r now
#     exit 0
# fi
# echo "transitional update completed with error."
# exit 1


# ~~ last line verification ~~