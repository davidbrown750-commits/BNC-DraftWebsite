#!/bin/sh

# Firmware upgrade tool, for ARMCONT and SOCCONT.
# Starting from now, it no longer replaces itself automatically.
# It is recommended to keep it that way due to risk of RMA: 
# if janitor fails, no more updates/restores are possible.

# clean update log: existence of file indicates error (fw may purposly misbehave)
rm "/anapico/dev/fwupdate"

homedir="/root"

downgrade() {
    tar -xvf $homedir/schoggibroedli.tar "matchingV2.txt" 
    if [ -f matchingV2.txt ]
    then
        echo "janitor is confused: Thinks is new package, but cant find handler."
        echo "Aborting now."
        shutdown -r now
        exit 1
    else
        echo "attempting to run in legacy mode"

        # extract everything, hope the package actually fits on taskit flash
        tar -xvf $homedir/schoggibroedli.tar

        # remove schoggibroedli, so janitor from package does not re-extract it
        rm $homedir/schoggibroedli.tar
        
        # rename janitor, so it doesnt find itself and thus cant replace device janitor
        # (cannot backup+restore janitor, as package janitor is expected to initiate reboot, 
        # potentially not running a single line of this script after its call).
        # New name also must not end in .sh, because legacy janitor executes all *.sh, 
        # leading to infinite recursion.
        mv janitor.sh legacy_janitor

        if [ -f ./janitor.sh ]
        then
            # paranoia check: MUST. NOT. EXIST. otherwise janitor downgrade and future mayhem
            echo "janitor is confused: Somehow failed to get rid of replacement janitor."
            echo "Aborting now. (device janitor left untouched.)"
            shutdown -r now
            exit 1 
        fi

        # All bets are off now. We are at the mercy of the janitor provided in the package.
        chmod +x legacy_janitor
        ./legacy_janitor

        # It is expected that the legacy janitor ends in reboot - but maybe not
        if [ $? -eq 0 ]
        then
            echo "legacy janitor claims to have exited without error. Rebooting now"
            shutdown -r now
            exit 0
        else
            echo "legacy janitor exited with error. Let's reboot and hope nothing bad has happened."
            shutdown -r now
            exit 0
        fi
    fi
}

cd $homedir
if [ -f "./schoggibroedli.tar" ]
then
    # nominal call (after janitor has stopped replacing itself with every update)
    
    rm -rf ./temp
    mkdir ./temp
    cd ./temp

    tar -xvf $homedir/schoggibroedli.tar "janitor"
    if grep -q -e "tastit" -e "taskit" /proc/cpuinfo
    then
        # armcont
        if [ -f ./janitor/armcont_janitor.sh ] 
        then
            # nominal run
            chmod +x ./janitor/armcont_janitor.sh
            ./janitor/armcont_janitor.sh $@
            retval=$?
        else
            # probably old package
            downgrade
        fi
    else
        # soccont
        if [ -f ./janitor/ahti ]
        then
            # nominal update
            chmod +x ./janitor/ahti
            ./janitor/ahti $@
            retval=$?
        else
            # probably old package
            if [ $(cat /etc/petalinux/product) = "AP_SOC_CONT" ]
            then
                # only supported for CONT1 / MSYN etc., not CONT2+
                downgrade
            else
                echo "Package is older than is supported by this device."
                echo "Aborting now."
                shutdown -r now
                exit 1
            fi
        fi
    fi

    # cleanup and reboot
    cd $homedir
    rm -rf ./temp
    rm "schoggibroedli.tar"
    shutdown -r now
    exit $retval

else 
    # janitor upgrade from previous version to this was considered here. 
    # (now outsourced to janitor_upgrade.sh script)
    echo "janitor is confused: Does not know where update data is."
    echo "Aborting now."
    exit 1
fi

# This should be impossible to reach; should exit in a way defined above in all cases
echo "janitor has run into unexpected EOF of itself."
exit 1
