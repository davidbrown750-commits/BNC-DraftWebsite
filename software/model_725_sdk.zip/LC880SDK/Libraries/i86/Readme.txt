These are 32-bit libraries

LC880sl.lib is a release library for static linking (MBCS)
LC880.lib is used to connect with LC880.dll at runtime, a dynamically linking release MBCS library
LC880u.lib is used to connect with LC880u.dll at runtime, a dynamically linking release unicode library
Make sure to place a copy of LC880.dll either in your system folder or preferably in the folder with your
executable or you will get a runtime error that it cannot find the dll