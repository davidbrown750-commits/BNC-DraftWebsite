// Validate.h : header file
//
#pragma once

/////////////////////////////////////////////////////////////////////////////
// CValidate 
#include "TimingMode.h"
class CValidate : public CTimingMode
{   
public:
	CValidate();    
	~CValidate();

	long MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);

	void GetDelayRange(double* pmin,double* pmax, const CLC880* pDev, TCHAR chan)const;
	void GetDurationRange(double* pmin,double* pmax, const CLC880* pDev, TCHAR chan)const;

	bool CheckParameters(const CLC880* pDev, TCHAR chan)const;
	const CValidate& operator=(const CValidate& o);

	SValidateProp m_ValidateProp;
	STriggerProp m_TriggerProp;
};

/////////////////////////////////////////////////////////////////////////////
