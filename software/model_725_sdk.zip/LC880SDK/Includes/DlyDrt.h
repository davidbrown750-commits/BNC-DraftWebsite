// DelayDurate.h : header file
//
#pragma once

#include "TimingMode.h"
/////////////////////////////////////////////////////////////////////////////
// CDelayDurate

class CDelayDurate : public CTimingMode
{   
public:
	CDelayDurate();  
	~CDelayDurate();

	long	MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);
	void	GetDelayRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const;
	void	GetDurationRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const;
	void	GetSweepRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const;

	bool	CheckParameters(const CLC880* pDev, TCHAR chan)const;

	const CDelayDurate& operator=(const CDelayDurate& o);


	STriggerProp m_TriggerProp;
	SSweepProp m_SweepProp;
	SDlyProp m_DlyProp;
};

/////////////////////////////////////////////////////////////////////////////
