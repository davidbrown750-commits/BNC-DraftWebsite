// Null.h : header file
//
#pragma once

#include "timingmode.h"
/////////////////////////////////////////////////////////////////////////////
// CNull
class CNull : public CTimingMode
{   
public:
	CNull();
	~CNull();

	long MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);

	const CNull& operator=(const CNull& o);

	SNullProp m_FixedProp;

};

/////////////////////////////////////////////////////////////////////////////
