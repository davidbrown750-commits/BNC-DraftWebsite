// DynDelayDurate.h : header file
//
#pragma once

#include "TimingMode.h"
/////////////////////////////////////////////////////////////////////////////
// CDynDelayDurate

class CDynDelayDurate : public CTimingMode
{   
public:
	CDynDelayDurate();  
	~CDynDelayDurate();

	long	MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);

	void	GetDelayRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const{*pmin = GetRealTime(4U,pDev,chan);*pmax = GetRealTime(4294967295U,pDev, chan);}
	void	GetDurationRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const{	*pmin = GetRealTime(1539U, pDev,chan); *pmax = GetRealTime(4294967295U,pDev,chan);}
	void	GetSweepRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const{*pmin = 0.0;*pmax = GetRealTime(4294967295U,pDev,chan);}

public:
	bool CheckParameters(const CLC880* pDev, TCHAR chan)const;
	
	const CDynDelayDurate& operator=(const CDynDelayDurate& o);

	SSweepProp m_SweepProp;
	SDlyProp m_DlyProp;
	SAveragingProp m_AvgProp;
};


/////////////////////////////////////////////////////////////////////////////
