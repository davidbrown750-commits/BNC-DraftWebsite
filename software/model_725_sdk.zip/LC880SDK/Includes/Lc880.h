

#pragma once

#define COMBAUD_2400	0
#define COMBAUD_4800	1
#define COMBAUD_9600	2
#define COMBAUD_19200	3
#define COMBAUD_38400	4

#include "SerDev.h"
class CChannel;
class CLogic;
struct SGeneral;
class CTimingMode;
class CSymbl;

class CLC880 : public CSerDev  
{
public:
	CLC880();
	void HandleUnsolicited(BYTE* pBuffer, DWORD nlength);
	virtual ~CLC880();
	int InitConnection(int nCOM, int nBaud);//use defines above to specify baudrate
	CChannel* GetChannel(TCHAR i)const;
	SGeneral* GetProp(){return m_pProp;}
	double GetClockFrequencyHz(TCHAR channel)const;

	bool SetGlobalLogic(const TCHAR* pGlobalText);

	bool CmdSetClock();
	bool CmdEnableOutputs();
	bool CmdDisableOutputs();
	bool CmdLockFP();
	bool CmdUnlockFP();
	bool CmdResetAll();
	bool CmdTransferAllLogic();
	bool CmdImplementLogic();
	bool CmdSetAllTimingModes();
	bool CmdUpdateAll();


	bool DoCommand(CCommand* pc);
	CSymbl** GetGlobalSymbols();
	
protected:
	CChannel** m_ppChannels;
	SGeneral* m_pProp;	
	CLogic* m_pLogic;
	unsigned int m_nQ;	
	BYTE m_query[8];	
};
