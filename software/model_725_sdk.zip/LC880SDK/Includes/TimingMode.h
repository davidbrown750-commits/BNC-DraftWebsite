// TimingMode.h: interface for the CTimingMode class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "TimingStructs.h"

class CCommand;
class CLC880;

class CTimingMode  
{

public:
	CTimingMode();
	virtual ~CTimingMode();

	virtual void GetDurationRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const;
	virtual void GetDelayRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const;

	virtual bool CheckParameters(const CLC880* pDev, TCHAR chan)const{return true;}

	virtual long MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan){return 0L;}

protected:
	double GetRealTime(UINT time, const CLC880* pDev, TCHAR chan)const;
	UINT GetClicks(double d, const CLC880* pDev, TCHAR chan)const;
	int m_nTabIndex;
	BYTE GetID(TCHAR chan)const;
};
