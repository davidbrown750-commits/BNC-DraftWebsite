// Passive.h : header file
//
#pragma once
/////////////////////////////////////////////////////////////////////////////
// CPassive 
#include "TimingMode.h"
class CPassive : public CTimingMode
{   
public:
	CPassive();
	~CPassive();
	long MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);
	CPassive& operator=(const CPassive& o);
	
	SPassiveProp m_PassiveProp;
};

/////////////////////////////////////////////////////////////////////////////
