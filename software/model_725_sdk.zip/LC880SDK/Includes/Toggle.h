// Toggle.h: interface for the CToggle class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "TimingMode.h"

class CToggle : public CTimingMode  
{
public:
	CToggle();
	virtual ~CToggle();

	long MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);

	const CToggle& operator=(const CToggle& o);
	
	SToggleProp m_ToggleProp;
};
