// Count.h : header file
//
#pragma once

#include "timingmode.h"
/////////////////////////////////////////////////////////////////////////////
// CCount 
class CCount : public CTimingMode
{   
	//NOTE: This mode is not currently implemented in the SDK

public:
	bool ParseQuery(BYTE* query, const CLC880* pDev, TCHAR chan, bool autoset = true);
	~CCount();
	CCount();

	long MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);
	SCounterProp m_CounterProp;

	const CCount& operator=(const CCount& o);
	
};

/////////////////////////////////////////////////////////////////////////////
