// Clock.h : header file
//
#pragma once

/////////////////////////////////////////////////////////////////////////////
// CClock 
#include "TimingMode.h"
class CClock : public CTimingMode
{   
public:
	bool IsUsingLogic()const{return false;}

	CClock();
	~CClock();
	long MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);
	void Destroy();
	void GetDelayRange(double* pmin, double* pmax, CLC880* pDev, TCHAR chan)const;
	void GetDurationRange(double* pmin, double* pmax, CLC880* pDev, TCHAR chan)const;

	bool CheckParameters(CLC880* pDev, TCHAR chan)const;	
	const CClock& operator=(CClock& o);

	SClockProp m_ClockProp;
};


/////////////////////////////////////////////////////////////////////////////
