// TimingStructs.h:
//
//////////////////////////////////////////////////////////////////////

#pragma once

struct SGeneral //Properties of the overall unit
{
	SGeneral():m_nTimeBaseAB(0),m_nTimeBaseCD(0),m_nTimeBaseEF(0),m_nTimeBaseGH(0),m_dExtClkFreq(100000000.0),
		m_bLockFP(0),m_bDisableIO(0)
	{
	}
	int m_nTimeBaseAB;	//time base used by pairs of channels (e.g., A and B)
	int m_nTimeBaseCD;	//n = 0: Use internal 100 MHz clock
	int m_nTimeBaseEF;	//n = 1: Use internal 100 MHz clock/64
	int m_nTimeBaseGH;	//n = 2: Use external clock
						//n = 3: Use external clock/64	
	double m_dExtClkFreq;// The external clock frequency (used to calculate timing)
	bool m_bLockFP;//lock the front panel?
	bool m_bDisableIO;//disable inputs and outputs
};

struct  STProp
{
};

struct  SLogicProp: public STProp
{
	SLogicProp():STProp(){m_LogicText[0] = 0;m_ChInSymbol[0] = 0;}
	TCHAR m_LogicText[4096];
	TCHAR m_ChInSymbol[4096];
};

struct  SToggleProp: public STProp
{
	SToggleProp():STProp(),m_bHigh(0){}
	bool m_bHigh;//Set = initial state is high
};

struct  SClockProp: public STProp
{
	SClockProp():STProp(),m_dHighDur(10.0e-6),m_dLowDur(10.0e-6),m_bInvert(0){}
	double m_dHighDur;//high duration (s)
	double m_dLowDur;//low duration (s)
	bool m_bInvert;//invert output?
};

struct  SNullProp: public STProp
{
	SNullProp():STProp(),m_bHigh(0){};
	bool m_bHigh;//Set = output high
};

struct  SCounterProp: public STProp
{
	SCounterProp():STProp(),m_bHold(0),m_bSaveCount(0),m_dLastDly(0.0),m_nTrigCount(0){m_FileName[0] = 0;}
	bool m_bHold;//hold last setting
	bool m_bSaveCount;//save to file?
	double m_dLastDly;//last measurement (s)
	TCHAR m_FileName[4096];//file name
	int m_nTrigCount;//count of measurements
};

struct  SDlyProp: public STProp
{
	SDlyProp():STProp(),m_bInvert(0),m_dDelay(20.0e-6),m_dDuration(10.0e-6),m_bInfDur(0){}
	bool m_bInvert;//invert output?
	double m_dDelay;//delay time (s)
	double m_dDuration;//duration of output pulse (s)
	bool m_bInfDur;//output high indefinitely?
};

struct  SPassiveProp: public STProp
{
	SPassiveProp():STProp(),m_bInvert(0){}
	bool m_bInvert;//Set = invert the output
};

struct  SScalingProp: public STProp // used for up-down count (dynamic delay)
{
	SScalingProp():STProp(),m_bLinearScaling(0),m_nLinScale(16),m_nBinScale(0){}
	bool m_bLinearScaling;//linear scale (otherwise 2^n)
	int m_nLinScale;//numerator of linear scale: 0 < m_nLinScale < 256.  Scale is m_nLinScale/16.
	int m_nBinScale;//exponent of binary scale: -16 < m_nBinScale < 16
};

struct  SSweepProp: public STProp
{
	SSweepProp():STProp(),m_bSweep(0),m_dSweepInc(0.0){}
	bool m_bSweep;//sweep the delay?
	double m_dSweepInc;//sweep increment (s / trigger)
};


struct  SAveragingProp : public STProp
{
	SAveragingProp() :STProp(), m_nAvgExp(0){}
	int m_nAvgExp;
};

struct  STriggerProp: public STProp
{
	STriggerProp():STProp(),m_bAlert(0),m_bEdgeTrigger(1),m_nRetriggerOption(0),m_nRetriggerCnt(0),m_nReset(0), m_bAsync(0){}
	bool m_bAlert;//unused leave as 0.
	bool m_bEdgeTrigger;//trigger on edge? (otherwise level triggered)
	int m_nRetriggerOption;//if (m_nRetriggerOption == 0) trigger indefinitely, once per input trigger
						// if (m_nRetriggerOption == 1) skip every m_nRetriggerCnt triggers
						// if (m_nRetriggerOption == 2) retrigger m_nRegtriggerCnt times
	int m_nRetriggerCnt;// See above
	int m_nReset;//if (m_nReset == 0)
				 //if (m_nReset == 1) reset 
	bool m_bAsync;//Reset asynchronously?
};

struct  SValidateProp: public STProp
{
	SValidateProp():STProp(),m_bInvert(0),m_dDelay(30.0e-6),m_dDuration(30.0e-6),m_bInfDur(0){}
	bool m_bInvert;//invert output?
	double m_dDelay;//delay AND minimum duration of a valid trigger pulse (s)
	double m_dDuration;//duration of output trigger pulse (s)
	bool m_bInfDur;//indefinite duration?
};

