// SerDev.h: interface for the CSerDev class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

class CCommand;
class CSerialBuffer;
class CSerDev  
{
public:
	CSerDev();
	virtual ~CSerDev();
	virtual void HandleUnsolicited(BYTE* pBuffer, DWORD nlength){}
	bool IsConnected()const{return m_bConnected;}
	virtual int CloseConnection();
protected:
	bool SendReceive(CCommand* pc);
	virtual int InitConnection(int nCOM, int nBaud);
	bool m_bConnected;
	bool Write(BYTE* pdata, int nCnd);
	bool m_bResponsePending;
private:
	CSerialBuffer* m_pBuffer;
	HANDLE m_hDataRx;
	HANDLE m_hCommPort;
	HANDLE m_hThreadTerm;
	HANDLE m_hThread;
	HANDLE m_hThreadStarted;

	HRESULT CSerDev::ReadN(BYTE* pData,long alCount, long  alTimeOut);
	void CloseAndCleanHandle(HANDLE& hHandle);
	void InvalidateHandle(HANDLE& hHandle );
	static unsigned __stdcall CommWatchProc(void*pvParam);
};
