#pragma once
// Channel.h : header file
//

class CChLogic;
class CLC880;
class CTimingMode;

class CChannel
{

// Construction
public:
	CChannel(CLC880* pDev, TCHAR id);
	virtual ~CChannel();

	//User commands:
	bool SetChannelLogic(const TCHAR* pLogicText);//pLogicText is the text of the logic setting for that channel, e.g.,
		// pLogicText = "inA = (not in1) or outB;" 
		// This command returns true if the logic text parses correctly.  If you are using Global symbols
		// make sure to set them first.
	bool CheckParameters()const;//verify timing mode parameters are within limits
	bool CheckLogic();// parse and verify logic settings are valid

	CTimingMode* SetTimingMode(CTimingMode* pTM);// Sets the new timing mode of a channel.
		//returns a pointer to the previous timing mode, if any.  Does not
		// delete the previous timing mode.
		// e.g.:    CDelayDurate* pnew = new CDelayDurate();
		//			CTimingMode* pold = SetTimingMode(pnew); //Set the new timing mode to a Delayed trigger
		//			delete pold;//delete the previous timing mode. 
		//			<now set the delay and triggering parameters, etc.
		//			<optionally verify the settings> if (!CheckParameters()) 
		//			{
		//				...
		//			}
		//			CmdSetTimingMode();//Now send the new setting to the LC880
	CTimingMode* GetTimingMode()const;

	bool CmdForceTrigger();
	bool CmdEnable();
	bool CmdDisable();
	bool CmdReset();
	bool CmdQuery();
	bool CmdSetTimingMode();
	bool CmdTransferLogic();//This command transfers the channel's logic to the LC880 but does not implement the setting
		// To implement the setting, use the function CLC880::CmdImplementLogic().

	static CTimingMode* SetDefaultTimingMode(CTimingMode* ptm);
	double GetLastDelay()const{return m_dLastDelay;}//Call to retrieve delay reported by Timer mode or CmdQuery(). Units are seconds.
	void SetLastDelay(UINT n);//Used internally
protected:
	CLC880 *m_pDev;
	TCHAR m_id;
	CTimingMode* m_pTM;
	CChLogic* m_pLogic;
	static CTimingMode* m_pDefaultMode;
	BYTE m_QueryBlock[16];
	double m_dLastDelay;
};

