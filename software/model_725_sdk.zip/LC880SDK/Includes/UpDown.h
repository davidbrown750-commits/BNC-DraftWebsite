// UpDown.h : header file
//
#pragma once

#include "timingmode.h"
/////////////////////////////////////////////////////////////////////////////
// CUpDown 

class CUpDown : public CTimingMode
{   
public:
	~CUpDown();
	CUpDown();
	void GetDelayRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const;
	void GetDurationRange(double* pmin, double* pmax, const CLC880* pDev, TCHAR chan)const;
	long MakeCommand(BYTE* command, const CLC880* pDev, TCHAR chan);

	bool CheckParameters(const CLC880* pDev,TCHAR chan)const;
	const CUpDown& operator=(const CUpDown& o);

	SScalingProp m_ScalingProp;
	STriggerProp m_TriggerProp;
	SDlyProp m_DlyProp;
};



/////////////////////////////////////////////////////////////////////////////
