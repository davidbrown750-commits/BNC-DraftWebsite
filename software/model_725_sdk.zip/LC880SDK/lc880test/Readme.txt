Sample application using the LC880 SDK. Open using Lc880test.sln.
See Lc880.cpp for an annotated demonstration of exercising the features of the SDK needed
to control the LC880.

***Important***: If using a dll, copy the library dll from Libraries\* into your executable folder or a folder that is in the DLL search path or you will get a 'dll not found' error. 

The libraries were built using VS 2015. See the readme.txt file in Libraries\i86\ or Libraries\x64\
for more information on library naming. Contact LabSmith if you require a newer version for your application.

See the SDK include files in Includes\ for some guidance on the meanings of variables used 
in the SDK.



 