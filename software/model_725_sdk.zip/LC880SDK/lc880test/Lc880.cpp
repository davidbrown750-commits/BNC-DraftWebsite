// Lc880.cpp : Defines the entry point for the console application.
// See TimingModes.h for a description of the variables used to set the channel functions
// This example shows how to perform all the major operations supported by the libraries
// The libraries are in the Lib\i86 and Lib\x64 folder.
// LC880sl.lib is a release library for static linking (MBCS)
// LC880sld.lib is a debug library for static linking (MBCS)
// LC880.lib is used to connect with LC880.dll at runtime, a dynamically linking release MBCS library
// LC880u.lib is used to connect with LC880u.dll at runtime, a dynamically linking release unicode library
// Make sure to place a copy of LC880.dll either in your system folder or preferably in the folder with your
// executable or you will get a runtime error that it cannot find the dll

#include "stdafx.h"
#include "..\Includes\Lc880.h"
#include "..\Includes\Channel.h"
#include "..\Includes\DlyDrt.h"//delayed trigger timing mode
#include "..\Includes\Clock.h"

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	CLC880 m_LC880;//Instantiate an LC880.  You can instantiate several if you
	// want to control several simultaneously on different COM ports.

	tcout << _T("\nOpening a connection to the LC880...");
	if (m_LC880.InitConnection(5, COMBAUD_38400) != 0)//Open an LC880 on COM5 @38400 Baud
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");

	tcout << _T("\nProgramming all settings to defaults...");
	if (!m_LC880.CmdUpdateAll())
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");

	CDelayDurate* pDD = new CDelayDurate();
	pDD->m_DlyProp.m_dDelay = 30.e-3;//Set delay to 30 ms
	pDD->m_DlyProp.m_dDuration = 40.e-3;//Set duration to 40 ms
	TCHAR chan;
	CChannel* pCh;

	tcout << _T("\nEditing the timing modes...");
	for (chan = 'A'; chan <= 'H'; chan++)
	{
		pCh = m_LC880.GetChannel(chan);
		CTimingMode* pOldTM = pCh->SetTimingMode(pDD);
		//the pOldTM is 0 because the channels have not yet been initialized to a timing mode
		//note you can share the same timing mode among different channels.  
		//This may or may not be useful, but you can do it.
	
		//Optionally verify that the settings are in range
		if (!pCh->CheckParameters())
		{
			tcout << _T("Failed!");
			return 1;
		}
	}
	tcout << _T("OK");

	tcout << _T("\nEditing the global logic symbols...");
	if (!m_LC880.SetGlobalLogic(_T("Start = not in1;")))
	{
		tcout << _T("Failed!");//problem with syntax of globals!
		return 1;
	}
	tcout << _T("OK");

	tcout << _T("\nEditing the logic settings...");
	pCh = m_LC880.GetChannel('A');
	if (!pCh->SetChannelLogic(_T("inA = Start or outG;")))
	{
		tcout << _T("Failed!"); //logic parse error!
		return 1;
	}
	TCHAR logic[256];
	for (chan = 'B'; chan <= 'H'; chan++)
	{
		_stprintf_s(&logic[0], 255, _T("in%c = out%c;"), chan, chan-1);
		pCh = m_LC880.GetChannel(chan);
		if (!pCh->SetChannelLogic(LPCTSTR(logic)))
		{
			tcout << _T("Failed!");//logic parse error!
			return 1;
		}
	}
	tcout << _T("OK");

	tcout << _T("\nDisabling inputs and outputs...");
	if (!m_LC880.CmdDisableOutputs())
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");

	tcout << _T("\nTransferring the logic...");
	if (!m_LC880.CmdTransferAllLogic())
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");

	tcout << _T("\nSetting the timing modes...");
	if (!m_LC880.CmdSetAllTimingModes())
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");
	
	tcout << _T("\nImplementing logic programming...");
	if (!m_LC880.CmdImplementLogic())
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");
	
	tcout << _T("\nEnabling inputs and outputs...");
	if (!m_LC880.CmdEnableOutputs())
	{
		tcout << _T("Failed");
		return 1;
	}
	tcout << _T("OK");
	
	tcout << _T("\nPausing 2 seconds...");
	Sleep(2000);
	tcout << _T("OK");
	
	tcout << _T("\nForcing a trigger on channel C...");
	if (!m_LC880.GetChannel('C')->CmdForceTrigger())
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");
	
	tcout << _T("\nPausing 4 seconds...");
	Sleep(4000);
	tcout << _T("OK");
	
	tcout << _T("\nResetting all channels...");
	if (!m_LC880.CmdResetAll())
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");

	tcout << _T("\nPausing 2 seconds...");
	Sleep(2000);
	tcout << _T("OK");

	tcout << _T("\nSetting channel A to a 10-Hz clock...");
	//Now set channel A to a 10 Hz clock.
	CClock* pClk = new CClock();
	pClk->m_ClockProp.m_dHighDur = 0.05;
	pClk->m_ClockProp.m_dLowDur = 0.05;

	pCh = m_LC880.GetChannel('A');
	pCh->SetTimingMode(pClk);
	if (!pCh->CheckParameters())
	{
		tcout << _T("Failed!");//parameters out of range!
		return 1;
	}
	if (!pCh->CmdSetTimingMode())//now send the new setting to the LC880
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");

	tcout << _T("\nPausing 2 seconds...");
	Sleep(2000);
	tcout << _T("OK");

	//Now quietly end the light show by setting chA back to a delayed trigger
	//and resetting the channel trigger states.
	pCh = m_LC880.GetChannel('A');
	pCh->SetTimingMode(pDD);
	pCh->CmdSetTimingMode();
	m_LC880.CmdResetAll();


	tcout << _T("\nClosing connection to LC880...");
	if (m_LC880.CloseConnection() != 0)
	{
		tcout << _T("Failed!");
		return 1;
	}
	tcout << _T("OK");

	tcout << _T("\n\nSuccess!\n");
	delete pDD;//free memory belonging to the timing modes
	delete pClk;
//	getchar();
	return nRetCode;
}


