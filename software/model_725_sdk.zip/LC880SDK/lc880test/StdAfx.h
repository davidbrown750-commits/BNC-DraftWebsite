// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//


#pragma once
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include "windows.h"
#include <iostream>
#include "tchar.h"
typedef unsigned char BYTE;
typedef unsigned int UINT;
typedef unsigned long DWORD;
#if defined(UNICODE) || defined(_UNICODE)
#define tcout std::wcout
#else
#define tcout std::cout
#endif


