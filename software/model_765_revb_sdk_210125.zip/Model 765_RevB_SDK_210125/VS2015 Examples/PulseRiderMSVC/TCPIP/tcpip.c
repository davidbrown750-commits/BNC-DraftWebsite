/*********************************************************************/
/* This example demonstrates opening a simple TCPIP connection and   */
/* does a read and checks a few properties.							 */
/*                                                                   */
/* The general flow of the code is                                   */
/*      Open Resource Manager                                        */
/*      Open a session to the TCP/IP site at NI                      */
/*      Perform a read, and check properties                         */
/*      Close all VISA Sessions                                      */
/*********************************************************************/

#include "visa.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char outputBuffer[VI_FIND_BUFLEN];
static ViSession defaultRM, instr;
static ViStatus status;
static ViUInt32 count;
static char acBuffer[10000000] = "";      

static const char acInstrument[] = "TCPIP::192.168.0.25::INSTR"; 

int main()
{
	int iIndex = 0;
	FILE* pFile = NULL;
	ViFindList objFindList;

	/* First we will need to open the default resource manager. */
	status = viOpenDefaultRM (&defaultRM);
	if (status < VI_SUCCESS)
	{
		printf("Could not open a session to the VISA Resource Manager!\n");
		exit (EXIT_FAILURE);
	}  

	status = viFindRsrc (defaultRM, "?*INSTR", &objFindList, &count, outputBuffer);
	if (status < VI_SUCCESS)
	{
		viStatusDesc(instr, status, outputBuffer);
		printf("viFindRsrc failed with error code %x - %s\n", status, outputBuffer);
		exit (EXIT_FAILURE);
	}  

	printf("viFindRsrc - %s\n", outputBuffer);

	/* Now we will open a session via TCP/IP */
	status = viOpen (defaultRM, (ViRsrc) acInstrument, VI_NULL, 20000, &instr);
	if (status < VI_SUCCESS)
	{
		printf ("An error occurred opening the session to %s\n", acInstrument);
		viClose(defaultRM);
		exit (EXIT_FAILURE);
	}

	viSetAttribute (instr, VI_ATTR_TMO_VALUE, 20000);

	pFile = fopen("sample1.txt", "r+");

	if(pFile != NULL)
	{
		char c = 0;

		do
		{
			c = (char) fgetc(pFile);

			if(c != EOF)
			{
				if(c != '\n')
				{
					acBuffer[iIndex++] = c;
				}
				else
				{
					printf("viWrite - %s \n", acBuffer);

					status = viWrite (instr, (ViBuf)acBuffer, iIndex, &count);

					if (status < VI_SUCCESS)
					{
						viStatusDesc(instr, status, outputBuffer);
						printf("viWrite failed with error code %x - %s\n", status, outputBuffer);
						viClose(defaultRM);
						exit (EXIT_FAILURE);
					}		 

					memset(outputBuffer, 0, sizeof(outputBuffer));

					status = viRead (instr, (ViBuf)outputBuffer, sizeof(outputBuffer), &count);

					if (status < VI_SUCCESS)
					{
						viStatusDesc(instr, status, outputBuffer);
						printf("viRead failed with error code %x - %s\n",status, outputBuffer);
						viClose(defaultRM);
						exit (EXIT_FAILURE);
					}

					outputBuffer[strlen(outputBuffer)-1] = 0;

					if(strlen(outputBuffer) > 0)
					{
						printf("The server response is:\n %s\n\n",outputBuffer);
					}

					memset(acBuffer, 0, sizeof(acBuffer));
					iIndex = 0;
				}
			}
			else
			{
				break;
			}

		}while(1);
	}

	status = viClose (instr);
	status = viClose (defaultRM);
	printf ("\nHit enter to continue.");
	fflush(stdin);
	getchar();

	return 0;  
}
