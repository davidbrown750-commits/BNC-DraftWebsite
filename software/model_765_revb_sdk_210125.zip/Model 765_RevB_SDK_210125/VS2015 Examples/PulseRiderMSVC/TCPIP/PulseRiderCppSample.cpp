/*********************************************************************/
/* This example demonstrates opening a simple TCPIP connection and   */
/* implements a single pulse generation in Continuous Mode.			 */
/*                                                                   */
/* The general flow of the code is                                   */
/*      Open Resource Manager                                        */
/*      Open a session to the TCP/IP site at NI                      */
/*      Perform write/read, and check properties                     */
/*      Close all VISA Sessions                                      */
/*********************************************************************/

#include "visa.h"

#include <stdio.h>
#include <stdlib.h>
#include <string>

static char outputBuffer[VI_FIND_BUFLEN];
static ViSession defaultRM, instr;
static ViStatus status;
static ViUInt32 count;
static char acBuffer[10000000] = "";   
static unsigned int u32Timeout = 20000; //timeout value in milliseconds

static const char acInstrument[] = "TCPIP::192.168.0.6::INSTR"; // instrument address

ViStatus VisaWrite(std::string sInput)
{
	printf("viWrite - %s \n", sInput.c_str());

	status = viWrite (instr, (ViBuf)sInput.c_str(), sInput.length(), &count);

	if (status < VI_SUCCESS)
	{
		viStatusDesc(instr, status, outputBuffer);
		printf("viWrite failed with error code %x - %s\n", status, outputBuffer);
		viClose(defaultRM);
		exit (EXIT_FAILURE);
	}	

	// In case of query command, retrieve the output string
	memset(outputBuffer, 0, sizeof(outputBuffer));

	status = viRead (instr, (ViBuf)outputBuffer, sizeof(outputBuffer), &count);

	if (status < VI_SUCCESS)
	{
		viStatusDesc(instr, status, outputBuffer);
		printf("viRead failed with error code %x - %s\n",status, outputBuffer);
		viClose(defaultRM);
		exit (EXIT_FAILURE);
	}

	outputBuffer[strlen(outputBuffer)-1] = 0;

	if(strlen(outputBuffer) > 0)
	{
		printf("The server response is:\n %s\n\n",outputBuffer);
	}

	return status;
}

int main()
{
	int iIndex = 0;
	FILE* pFile = NULL;
	ViFindList objFindList;

	/* First we will need to open the default resource manager. */
	status = viOpenDefaultRM (&defaultRM);
	if (status < VI_SUCCESS)
	{
		printf("Could not open a session to the VISA Resource Manager!\n");
		exit (EXIT_FAILURE);
	}  

	status = viFindRsrc (defaultRM, "?*INSTR", &objFindList, &count, outputBuffer);
	if (status < VI_SUCCESS)
	{
		viStatusDesc(instr, status, outputBuffer);
		printf("viFindRsrc failed with error code %x - %s\n", status, outputBuffer);
		exit (EXIT_FAILURE);
	}  

	printf("viFindRsrc - %s\n", outputBuffer);

	/* Now we will open a session via TCP/IP */
	status = viOpen (defaultRM, (ViRsrc) acInstrument, VI_NULL, u32Timeout, &instr);
	if (status < VI_SUCCESS)
	{
		printf ("An error occurred opening the session to %s\n", acInstrument);
		viClose(defaultRM);
		exit (EXIT_FAILURE);
	}

	// Set the timeout attribute
	viSetAttribute (instr, VI_ATTR_TMO_VALUE, u32Timeout);

	//Identify and reset the instrument
	VisaWrite("*IDN?");
	VisaWrite("*RST");
	//Set the Channel Parameters
	VisaWrite("SOURce1:PERiod 600 ns");
	VisaWrite("SOURce2:PERiod 600 ns");
	VisaWrite("SOURce1:VOLT:HIGH 1");
	VisaWrite("SOURce1:VOLT:LOW -1");
	VisaWrite("SOURce2:VOLT:HIGH 0.5");
	VisaWrite("SOURce2:VOLT:LOW -0.5");
	// Set the Pulse Parameters
	VisaWrite("SOURce1:PULSe1:WIDth 100 ns");
	VisaWrite("SOURce2:PULSe1:WIDth 20 ns");
	// Turn On the Outputs
	VisaWrite("OUTPut1 ON");
	VisaWrite("OUTPut2 ON");
	// Set the Pulse Mode
	VisaWrite("SOURce1:PULSe:MODE SINGLE");
	// Set the Trigger Mode
	VisaWrite("TRIGger:MODE CONTinuous");
	// Arm the instrument
	VisaWrite("PULSEGENControl:START");
	// Start the generation
	VisaWrite("*TRG");

	status = viClose (instr);
	status = viClose (defaultRM);
	printf ("\nHit enter to continue.");
	fflush(stdin);
	getchar();

	return 0;  
}


