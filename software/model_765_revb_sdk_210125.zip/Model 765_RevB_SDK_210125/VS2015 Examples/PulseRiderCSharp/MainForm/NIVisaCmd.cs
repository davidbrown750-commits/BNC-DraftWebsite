﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NationalInstruments.Visa;
using System.Windows.Forms;

namespace MainForm
{
    class NIVisaCmd
    {
        private string _openError;

        public int BufferSize { get; set; }
        public int RetryCount { get; set; }
        public long TimeOut { get; set; }

        private MessageBasedSession m_objMBS;

        public MessageBasedSession ObjMBS
        {
            get
            {
                return m_objMBS;
            }

            set
            {
                m_objMBS = value;
            }
        }

        public NIVisaCmd()
        {
            BufferSize = 256;
            RetryCount = 1;
            TimeOut = 2000;
        }

        public string SendTo(string address, string message)
        {
            string strResponse = string.Empty;
            var rmSession = new ResourceManager();

            try
            {
                string textToWrite = ReplaceCommonEscapeSequences(message);
                ObjMBS.RawIO.Write(textToWrite);
                // Get the return string
                strResponse = ObjMBS.RawIO.ReadString();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            return strResponse;
        }
        private string ReplaceCommonEscapeSequences(string s)
        {
            return s.Replace("\\n", "\n").Replace("\\r", "\r");
        }

        private string InsertCommonEscapeSequences(string s)
        {
            return s.Replace("\n", "\\n").Replace("\r", "\\r");
        }
    }
}
