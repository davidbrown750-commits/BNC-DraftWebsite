﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NationalInstruments.Visa;
using System.IO;

namespace MainForm
{
    public partial class Form1 : Form
    {
        public MessageBasedSession mbSession;
        public ResourceManager rmSession = new ResourceManager();
        MainForm.NIVisaCmd vs = new MainForm.NIVisaCmd();
        static int lTimeout = 20000; // Timeout value in milliseconds
        static string sInstrumentAddress = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            vs.TimeOut = lTimeout;
            btnGeneratePulse.Enabled = false;
            btnLoadScript.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                mbSession = (MessageBasedSession)rmSession.Open(tbAddress.Text); 
                mbSession.TimeoutMilliseconds = lTimeout;
                vs.ObjMBS = mbSession;
                tbAnswer.Text = vs.SendTo(tbAddress.Text, "*IDN?");
                if (tbAnswer.Text.Contains("AT-PULSE-RIDER"))
                {
                    btnGeneratePulse.Enabled = true;
                    btnLoadScript.Enabled = true;
                    sInstrumentAddress = tbAddress.Text;
                }
            }
            catch (InvalidCastException)
            {
                MessageBox.Show("Resource selected must be a message-based session");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

        }

        private void btnLoadScript_Click(object sender, EventArgs e)
        {
            // Load a SCPI script
            openFileDialog1.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";
            openFileDialog1.Title = "Please select the SCPI script";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Execute the script
                if (File.Exists(openFileDialog1.FileName))
                {
                    using (StreamReader reader = new StreamReader(openFileDialog1.FileName, true))
                    {
                        int cnt = 1;
                        string ln = reader.ReadLine();
                        while (ln != null)
                        {
                            if (ln.Length > 0)
                            {
                                Console.WriteLine("{0}> {1}", cnt, ln);

                                if (!ln.EndsWith("\n"))
                                    ln += '\n';

                                tbAnswer.Text = vs.SendTo(sInstrumentAddress, ln);
                            }
                            ln = reader.ReadLine();
                            cnt++;
                        }
                    }
                }
            }
        }

        private void btnGeneratePulse_Click(object sender, EventArgs e)
        {
            // Reset to default
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "*RST");
            // Set the channel parameters
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "SOURce1:VOLT:HIGH 1.5");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "SOURce1:VOLT:LOW -1.5");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "SOURce2:VOLT:HIGH 2");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "SOURce2:VOLT:LOW -2");
            // Set the pulse parameters
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "SOURce1:PULSe1:WIDth 50 ns");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "SOURce1:PULSe1:DELay 0");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "SOURce2:PULSe1:WIDth 50 ns");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "SOUrce2:PULSe1:DELay 50 ns");
            // Set the pulse mode
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "OUTPut1:PULSe:MODe SINgle");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "OUTPut2:PULSe:MODe SINgle");
            // Turn On the channels
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "OUTPut1 ON");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "OUTPut2 ON");
            // Set the trigger mode and arm the instrument
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "TRIGger:MODE CONTinuous");
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "PULSEGENControl:START");
            // Send the trigger
            tbAnswer.Text = vs.SendTo(sInstrumentAddress, "*TRG");
        }
    }
}
