﻿<?xml version='1.0' encoding='UTF-8'?>
<Library LVVersion="13008000">
	<Property Name="Instrument Driver" Type="Str">True</Property>
	<Property Name="NI.Lib.Description" Type="Str">LabView Examples for Active Technologies Pulse Rider PG-1000 RevB</Property>
	<Property Name="NI.Lib.HelpPath" Type="Str"></Property>
	<Property Name="NI.Lib.Icon" Type="Bin">%Q#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!!*,!!!*Q(C=\&gt;1R&lt;NN!%)8B:]/&amp;5QKZA-%LT"85J!`,N(-&amp;N7Y#+,\"V(9;F1%L-U?9+_A+OI,S=TG58&amp;G.$4C!O2K:@,P=`543F.JW+^XI?'E&lt;8NWG`F:$KWF]K_FI0FD[ZT9M1WPX.(:JZ^.KQG&amp;'V,D4W=&gt;T`\"--:S80(UO_P8K^NH`W@^`^V`9'(.`=&gt;!\&lt;^*6EV**"?75N6^X40)E4`)E4`)E$`)A$`)A$`)A&gt;X)H&gt;X)H&gt;X)H.X)D.X)D.X)D&lt;YV=Z#)8/6=F74R:+*EUG3!:$%8*6_**0)EH]8#IR*.Y%E`C34Q-5?**0)EH]31?4F0C34S**`%E(K:KEGS.(%`C98I&amp;HM!4?!*0Y'&amp;*":Y!%#Q74"R-!E.":\!4?!*0Y'&amp;8A3@Q"*\!%XDI6O!*0)%H]!1?4GF8*:JG;O2YG%;/R`%Y(M@D?*B;DM@R/"\(YXB94I\(]4A):U&amp;H=ABS4H)'/!?/R`(Q2Y\(]4A?R_.Y['JXS.O6G424)]&gt;D?!S0Y4%]BI=J:(A-D_%R0);(;76Y$)`B-4S'B[6E?!S0Y4%ARK)M,W-SYU2DE"%9(D\N;&lt;&amp;WF[**L,8[VZQ@6.5$K(KQ6!_-[E&amp;1X7$6D60&gt;%.7&amp;6FV!V962`7$6$V%"61OL*F1.V)(P0463/WJ,&lt;;C?7F-&gt;N:J/@?/"B]."_`V?YTBKN^NJO^VKM^GI\XONVWNV8;@6;H6[7^X2ZOVK?3`&gt;MR^@HX`%^_\H\X\]]P@JY&gt;@4YZ^P5`[?.&lt;_80M+\5&gt;=[PHD.=YX_!15;J.5!!!!!</Property>
	<Property Name="NI.Lib.SourceVersion" Type="Int">318799872</Property>
	<Property Name="NI.Lib.Version" Type="Str">2.0.0.0</Property>
	<Property Name="NI.LV.All.SourceOnly" Type="Bool">false</Property>
	<Property Name="NI.SortType" Type="Int">3</Property>
	<Item Name="Public" Type="Folder">
		<Property Name="NI.LibItem.Scope" Type="Int">1</Property>
		<Item Name="Configure" Type="Folder">
			<Item Name="Channel" Type="Folder">
				<Item Name="SetPulseParameters.vi" Type="VI" URL="../Public/Configure/Channel/SetPulseParameters.vi"/>
				<Item Name="SetChannelParameters.vi" Type="VI" URL="../Public/Configure/Channel/SetChannelParameters.vi"/>
				<Item Name="SetPulseMode.vi" Type="VI" URL="../Public/Configure/Channel/SetPulseMode.vi"/>
				<Item Name="SetTriggerParameters.vi" Type="VI" URL="../Public/Configure/Channel/SetTriggerParameters.vi"/>
			</Item>
			<Item Name="SetTriggerIN.vi" Type="VI" URL="../Public/Configure/SetTriggerIN.vi"/>
			<Item Name="SetClockSource.vi" Type="VI" URL="../Public/Configure/SetClockSource.vi"/>
			<Item Name="SetTriggerOut.vi" Type="VI" URL="../Public/Configure/SetTriggerOut.vi"/>
		</Item>
		<Item Name="Utility" Type="Folder">
			<Item Name="Error Query.vi" Type="VI" URL="../Public/Utility/Error Query.vi"/>
			<Item Name="Reset.vi" Type="VI" URL="../Public/Utility/Reset.vi"/>
			<Item Name="Revision Query.vi" Type="VI" URL="../Public/Utility/Revision Query.vi"/>
			<Item Name="TCPIP Load Script.vi" Type="VI" URL="../Public/Utility/TCPIP Load Script.vi"/>
		</Item>
		<Item Name="Close.vi" Type="VI" URL="../Public/Close.vi"/>
		<Item Name="Initialize.vi" Type="VI" URL="../Public/Initialize.vi"/>
	</Item>
	<Item Name="Private" Type="Folder">
		<Property Name="NI.LibItem.Scope" Type="Int">2</Property>
		<Item Name="Default Instrument Setup.vi" Type="VI" URL="../Private/Default Instrument Setup.vi"/>
		<Item Name="Match String.vi" Type="VI" URL="../Private/Match String.vi"/>
		<Item Name="Retrieve Token String.vi" Type="VI" URL="../Private/Retrieve Token String.vi"/>
	</Item>
</Library>
