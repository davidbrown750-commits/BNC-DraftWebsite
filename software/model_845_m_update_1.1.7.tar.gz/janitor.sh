####################################
#                                  #
# AnaPico Software Management Tool #
#                                  #
# (c) 2011-2024 by AnaPico AG      #
#                                  #
####################################

########################################################
# clean directory structure                            #
########################################################
rm /gmon.out
cd /root

for item in *; do
    # Skip the script itself, the firmware package and the temp folder
    if [[ "$item" != "janitor.sh" && "$item" != "temp" && "$item" != "schoggibroedli.tar" ]]; then
        echo "deleting $item..."
        rm -rf "$item"
    fi
done

mkdir -p ./temp

########################################################
# kill background processes                            #
########################################################

killall httpd
killall vsftpd
killall AP_websockify

#########################################################
# extract sources if necessary                          #
#########################################################
cd ./temp
if [ -e "../schoggibroedli.tar" ]
then
        cd /root
        rm -r ./temp
        mkdir -p ./temp
        cd ./temp
        tar -xvf ../schoggibroedli.tar
        rm ../schoggibroedli.tar
fi

#########################################################
# check firmware update prerequisites                   #
#########################################################
if [ "$(uname -a)" == "Linux instr0 2.6.33 #58 PREEMPT Tue May 12 15:05:59 CEST 2015 armv5tejl unknown" ]
then
    echo "Running on a 12.05.2015 kernel, checking firmware compatibility"
    if [ -n "$(cat ./packageinfo | grep linux_kernel=12.05.2015)" ]
    then
            echo "Firmware supports 12.05.2015 kernel"
    else
            echo "Error: Firmware does not support 12.05.2015 kernel"
            cd ../
            rm -r ./temp
            exit 0
    fi
fi

if [ -e "/bin/write_root" ]
then
        echo "Read-only root file system, checking firmware compatibility"
        if [ -e ./packageinfo ]
        then
                if [ -n "$(cat ./packageinfo | grep ro_root_support=yes)" ]
                then
                        echo "Firmware supports read-only root file systems"
                else
                        echo "Error: Firmware does not support read-only root file systems"
                        cd ../
                        rm -r ./temp
                        exit 0
                fi
        else
                echo "Error: Missing package information file"
                echo "Error: Assume firmware does not support read-only root file systems"
                cd ../
                rm -r ./temp
                exit 0
        fi
else
        echo "Read-write root file system, skipping firmware compatibility check"
fi

for filename in ./janitor/*.sh
do
    if [ -f "$filename" ]
    then
        echo "Executing janitor check script $filename"
	    chmod 777 $filename
	    $filename
        rc=$?
	    rm $filename
        if [[ $rc != 0 ]]
        then
            echo "Update cancelled by janitor check script $filename"
            cd ../
            rm -r ./temp
            exit 0
        fi
    fi
done

#########################################################
# overwrite janitor.sh if available and restart         #
#########################################################
echo "Check if janitor.sh should be replaced"
if [ -f ./janitor.sh ]
then
        echo "Replacing janitor.sh"
	mv ./janitor.sh ../janitor.sh
	chmod 777 ../janitor.sh
	../janitor.sh
	exit 0
fi

#########################################################
# update payload                                        #
#########################################################
echo "Check if package needs to be decrypted"
if [ -f ./payload ]
then
    echo "Running decryptor (updater)"
    ./updater
    rm payload
fi
tar -xvf payload.tar
rm payload.tar

#########################################################
# clean previous firmware upgrade logs                  #
#########################################################
rm "/anapico/dev/fwupdate"

#########################################################
# execute shell script delivered with software          #
#########################################################
for filename in ./*.sh
do
    echo "Executing $filename"
	chmod 777 $filename
	$filename
	rm $filename
done


#########################################################
# clean up                                              #
#########################################################
cd ../
rm -r ./temp

#########################################################
# reboot                                                #
#########################################################
shutdown -r now

exit 0
