#!/bin/sh
# Make sure we run on the Zynq / AP_SOC_CONT_1 platform. Otherwise abort upgrade process.

echo "Checking platform, this package is for Zynq / AP_SOC_CONT_1"
if [ "$(cat /etc/petalinux/product)" == "AP_SOC_CONT" ]
then
    echo "    info: Zynq / AP_SOC_CONT_1 platform"
    exit 0
else
    echo "    error: unknown platform"
    exit 1
fi

