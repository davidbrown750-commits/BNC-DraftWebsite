#!/bin/sh
echo "Front panel update"

# Find installed front panel and upload firmware
snstr=$(cat /anapico/dev/sn)

if [ ${snstr:4:1} == "3" ]
then
	echo "Front panel type: Touch panel STM, uploading firmware"
	if [ -f ./tp_stm_flash.bin ]
	then
		# Upload firmware, preserve flash sector 1 (used as EEPROM)
		./update_hc_zynq.bin ./tp_stm_flash.bin /dev/ttyPS1 stm keeps1
		rm ./tp_stm_flash.bin
	else
		echo "Front panel firmware not available, skipping update"
	fi
else
    echo "Front panel not installed, skipping firmware update"
fi
echo "Front panel update done"
cd $(pwd)

