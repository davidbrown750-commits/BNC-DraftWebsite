#!/bin/sh

# Insert device name here: DEVICE="DEVICE_NAME"
# makepackage.sh will do that automatically by replacing the next line
# Do not use that in other scripts - makepackage.sh does that only for 50_main_update.sh
DEVICE="MODEL_825-20"

echo "50_main_update.sh: terminate firmware"
killall $DEVICE 2> /dev/null
killall $(cat /etc/init.d/ap_run) 2> /dev/null
killall $DEVICE 2> /dev/null
killall $(cat /etc/init.d/ap_run) 2> /dev/null
sleep 1
echo ""
echo "50_main_update.sh: firmware terminated"

##########################################
# check kernel module init script        #
##########################################
echo "50_main_update.sh: check kernel module init script"

##########################################
# remove obsolete kernel modules         #
##########################################
echo "50_main_update.sh: remove obsolete kernel modules"

##########################################
# update all kernel modules              #
##########################################
echo "50_main_update.sh: install or update kernel modules"
echo "#!/bin/sh" > /etc/init.d/ap_modules
for module_name in *.ko
do
	if [ $module_name == "ap-usbtmc.ko" ]
	then
		echo "if [ -f /anapico/dev/sn ]" >> /etc/init.d/ap_modules
		echo "then" >> /etc/init.d/ap_modules
		echo "	SN=\$(cat /anapico/dev/sn)" >> /etc/init.d/ap_modules
		echo "else" >> /etc/init.d/ap_modules
		echo "	SN=000-000000000-0000" >> /etc/init.d/ap_modules
		echo "fi" >> /etc/init.d/ap_modules
		echo "insmod /lib/modules/4.19.0-xilinx-v2019.1/extra/$module_name serial_number=\$SN" >> /etc/init.d/ap_modules
	fi
	mv $module_name /lib/modules/4.19.0-xilinx-v2019.1/extra/$module_name
done;
chmod 777 /etc/init.d/ap_modules

##########################################
# create firmware init and fallback      #
# scripts                                #
##########################################
echo "50_main_update.sh: create firmware init / fallback script"
if [ ! -f /etc/init.d/ap_run ]
then
	touch /etc/init.d/ap_run
	chmod 777 /etc/init.d/ap_run
fi
if [ ! -f /etc/init.d/ap_fallback ]
then
	touch /etc/init.d/ap_fallback
	chmod 777 /etc/init.d/ap_fallback
fi

####################################################################################################
# Update bitstream                                                                                 #
#     Earlier a runlevel script has been used to load the bitstream during boot.                   #
#     However it can be loaded by the firmware instead. This offers two advantages:                #
#     - the update process is simpler (no need to update runlevel scripts)                         #
#     - the firmware has to reset the FPGA part anyway so it makes sense to load the bitstream     #
#       there too.                                                                                 #
#     The bitstream must still be loaded here because later update scripts may need it to be up to #
#     date, e.g. the front panel updater.							   #
####################################################################################################
echo "50_main_update.sh: update bitstream"
if [ -e /etc/rc5.d/S69ap_fpga_bitstream ]
then
	rm /etc/rc5.d/S69ap_fpga_bitstream
fi
if [ -e ./custom_design_wrapper.bit.bin ]
then
	echo "        copying and loading custom_design_wrapper.bit.bin"
	mv ./custom_design_wrapper.bit.bin /lib/firmware/custom_design_wrapper.bit.bin
	echo 0 > /sys/class/fpga_manager/fpga0/flags
	echo custom_design_wrapper.bit.bin > /sys/class/fpga_manager/fpga0/firmware
fi

##########################################
# update firmware                        #
##########################################
echo "50_main_update.sh: write firmware loader script"
if [ -e ./$DEVICE ]
then
	# always write the new binary to the start up script
	echo $DEVICE > /etc/init.d/ap_run
	mv ./$DEVICE /bin/$DEVICE

	# Write fallback firmware loader script
	echo "#!/bin/sh" > /etc/init.d/ap_fallback
	echo 'if [ -e /media/ram/ap_framework_status ]' >> /etc/init.d/ap_fallback
	echo 'then' >> /etc/init.d/ap_fallback
	echo '    echo /media/ram/ap_framework_status exists' >> /etc/init.d/ap_fallback
	echo '    if [ $(cat /media/ram/ap_framework_status) != "exit_success" ]' >> /etc/init.d/ap_fallback
	echo '    then' >> /etc/init.d/ap_fallback
	echo '        echo framework running or exited with failure' >> /etc/init.d/ap_fallback
	echo "        $DEVICE -f" >> /etc/init.d/ap_fallback
	echo '    else' >> /etc/init.d/ap_fallback
	echo '        echo framework exited with success' >> /etc/init.d/ap_fallback
	echo '    fi' >> /etc/init.d/ap_fallback
	echo 'else' >> /etc/init.d/ap_fallback
	echo '    echo /media/ram/ap_framework_status missing' >> /etc/init.d/ap_fallback
	echo '    echo no framework status information available' >> /etc/init.d/ap_fallback
	echo 'fi' >> /etc/init.d/ap_fallback
fi

##########################################
# check anapico partition                #
##########################################
echo "50_main_update.sh: check AnaPico partition"

##########################################
# write all *.csv scripts to             #
# /anapico/dev                           #
# (calibration upgrade option)	     	 #
##########################################
echo "50_main_update.sh: copy data tables"
filelist=`ls | grep *.csv`
for file_name in $filelist
do
	mv $file_name /anapico/dev/$file_name
done;

##########################################
# overwrite linux kernel                 #
##########################################
echo "50_main_update.sh: kernel update"

echo "Checking RAM size to determine platform type"
MEM_TOTAL_KB=`grep MemTotal /proc/meminfo | grep -oe '\([0-9.]*\)'`
if [ $MEM_TOTAL_KB -eq 251692 ]
then
	echo "    "$MEM_TOTAL_KB" kB -> 1 DDR chip (AP_SOC_CONT_DDRx1 platform)"
	KERNEL_FILE="image_QSPI_DDRx1.ub"
else
	echo "    "$MEM_TOTAL_KB" kB -> 2 DDR chips (AP_SOC_CONT_DDRx2 platform)"
	KERNEL_FILE="image_QSPI_DDRx2.ub"
fi
echo "    Bootloader image"$KERNEL_FILE

if [ -e ./${KERNEL_FILE} ]
then
	KERNEL_PART="/dev/mtd2"
	printf "\nWriting ${KERNEL_FILE} To QSPI Flash @${KERNEL_PART}\n"
	/usr/sbin/flashcp -v ${KERNEL_FILE} ${KERNEL_PART}
fi


##########################################
# overwrite uboot                        #
##########################################
echo "50_main_update.sh: uboot update"

echo "Checking RAM size to determine platform type"
MEM_TOTAL_KB=`grep MemTotal /proc/meminfo | grep -oe '\([0-9.]*\)'`
if [ $MEM_TOTAL_KB -eq 251692 ]
then
	echo "    "$MEM_TOTAL_KB" kB -> 1 DDR chip (AP_SOC_CONT_DDRx1 platform)"
	BOOT_FILE="BOOT_QSPI_DDRx1.BIN"
else
	echo "    "$MEM_TOTAL_KB" kB -> 2 DDR chips (AP_SOC_CONT_DDRx2 platform)"
	BOOT_FILE="BOOT_QSPI_DDRx2.BIN"
fi
echo "    Bootloader image"$BOOT_FILE

if [ -e ./${BOOT_FILE} ]
then
	BOOT_PART="/dev/mtd0"
	printf "\nWriting ${BOOT_FILE} Image To QSPI Flash @${BOOT_PART}\n"
	/usr/sbin/flashcp -v ${BOOT_FILE} ${BOOT_PART}
fi

##########################################
# check if hostname is still valid       #
##########################################
echo "50_main_update.sh: check hostname"

APMAC=$(cat /anapico/dev/conf/eth0_mac.config)
APMAC2=$(cut -d "=" -f2- <<< $APMAC | sed s/://g)
CURHOST=$(cat /anapico/dev/conf/hostname)
if [ $DEVICE$APMAC2 != $CURHOST ]
then
	echo $DEVICE$APMAC2 > /anapico/dev/conf/hostname
fi

