#!/bin/sh

#############################################
# Add/Update web user interface             #
#############################################
echo "Adding webUI support"

cp -rf webUI/usr/bin/* /usr/bin/
chmod 777 /usr/bin/APwebsockify

cp -f webUI/inetd.conf /etc/

cp -f webUI/APwebsockify.sh /etc/init.d/
ln -s /etc/init.d/APwebsockify.sh /etc/rc5.d/S59APwebsockify


# if [ -z "$(grep 'AP_websockify' /etc/inetd.conf)" ]  
# then
#   cp webUI/inetd.conf /etc/inetd.conf
# fi

# mkdir /anapico/temp/www/
# mkdir /anapico/dev/www/
cp -rf webUI/www/* /anapico/dev/www/
chmod 744 /anapico/dev/www

if [ -f "/anapico/dev/fw_info" ]
then
	. /anapico/dev/fw_info
	sed -i 's/let companyName = \"AnaPico AG\"\;/let companyName = \"'"$MANUFACTURER"'\"\;/g' /anapico/dev/www/webui.html
	sed -i 's+let companyUrl = \"anapico.com\"\;+let companyUrl = \"'"$URL"'\"\;+g' /anapico/dev/www/webui.html
	sed -i 's/let logoFileName = \"AnaPico_Logo.png\"\;/let logoFileName = \"'"img\/$LOGO"'\"\;/g' /anapico/dev/www/webui.html
	sed -i 's/let companyEMailAdress = \"support@anapico.com\"\;/let companyEMailAdress = \"\"\;/g' /anapico/dev/www/webui.html
fi



rm -rf webUI

echo "Added webUI support"

