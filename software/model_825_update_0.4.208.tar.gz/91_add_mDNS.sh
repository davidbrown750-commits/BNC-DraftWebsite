#!/bin/sh

#############################################
# Add mDNS services for VX-11/LXI incl.     #
# httpd for identification file             #
#############################################
echo "Adding mDNS support"


############################################
# remove unused avahi services and add scpi#
############################################


if [ -e "/etc/avahi/services/sftp-ssh.service" ]
then 
	rm /etc/avahi/services/sftp-ssh.service
	rm /etc/avahi/services/ssh.service
fi
if [ -e "/etc/avahi/services/scpi-raw.service" ]
then
	rm /etc/avahi/services/scpi-raw.service
fi

mv mDNS_avahi/inetd.conf /etc/inetd.conf
mv mDNS_avahi/httpd.conf /etc/httpd.conf
mv mDNS_avahi/http.service /etc/avahi/services/http.service

#mkdir /anapico/temp/www/
rm -rf /anapico/dev/www
mkdir /anapico/dev/www/


chmod 744 /anapico/dev/www
mkdir /anapico/dev/www/lxi
chmod 744 /anapico/dev/www/lxi
cp -fr mDNS_avahi/www/* /anapico/dev/www/


mv fw_info /anapico/dev/fw_info

if [ -e "/etc/network/if-up.d/eth0_generate_avahi_scpi" ]
then
	rm /etc/network/if-up.d/eth0_generate_avahi_scpi*
fi

mv mDNS_avahi/AP_generateAvahiServices /usr/sbin/AP_generateAvahiServices
chmod 777 /usr/sbin/AP_generateAvahiServices

mv mDNS_avahi/avahi-daemon /etc/init.d/avahi-daemon
chmod 7777 /etc/init.d/avahi-daemon

mv mDNS_avahi/avahi-autoipd.action /etc/avahi/avahi-autoipd.action
chmod 777 /etc/avahi/avahi-autoipd.action

mv mDNS_avahi/50default /etc/udhcpc.d/50default

if [ -z "$(grep 'hostname' /etc/network/interfaces)" ] &&  [ -n "$(grep 'dhcp' /etc/network/interfaces)" ]
then
   echo '    hostname $(hostname)' >> /etc/network/interfaces
fi



if [ -z "$(grep 'post-up' /anapico/dev/conf/eth0_dhcp_conf)" ]  
then
    echo "post-up /usr/sbin/AP_generateAvahiServices" >> /anapico/dev/conf/eth0_dhcp_conf
    echo "post-up /usr/sbin/AP_generateAvahiServices" >> /anapico/dev/conf/eth0_auto_conf
fi
if [ -z "$(grep 'post-up' /anapico/dev/conf/interfaces)" ]  
then
    echo "post-up /usr/sbin/AP_generateAvahiServices" >> /anapico/dev/conf/interfaces
fi




if [ -f "/anapico/dev/sn" ]
then
	SERNR_TOTAL=$(cat /anapico/dev/sn)
	SERNR=$(echo $SERNR_TOTAL | awk '{split($0,a,"-"); print a[3]}')
	# echo $SERNR
else
	SERNR=0000
fi

if [ -f "/anapico/dev/fw_info" ]
then
	. /anapico/dev/fw_info
else
	MANUFACTURER=Anapico
	URL="http://www.anapico.com"
	LOGO="logoAP.png"
	STYLE="styleAP.css"
	FWVERSION="1.0.0"
	MODEL="AP-T&M"
fi


if test -f /etc/hostname
then
	# hostname -F /etc/hostname
	# hostname $MODEL-$SERNR
	echo "$MODEL-$SERNR" > /etc/hostname
fi




















echo "Added mDNS support"

