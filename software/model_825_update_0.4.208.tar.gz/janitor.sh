#!/bin/sh

####################################
#                                  #
# Anapico Firmware Upgrade Tool    #
#                                  #
# (c) 2020 by AnaPico AG           #
#                                  #
####################################

########################################################
# clean directory structure                            #
########################################################
cd /root
mkdir -p ./temp

#########################################################
# extract sources if necessary                          #
#########################################################
cd ./temp
if [ -e "../schoggibroedli.tar" ]
then
        cd /root
        rm -r ./temp
        mkdir -p ./temp
        cd ./temp
        tar -xvf ../schoggibroedli.tar --warning=no-timestamp
        rm ../schoggibroedli.tar
fi

#########################################################
# check firmware update prerequisites                   #
#########################################################

echo "Checking if package supports this platform"
if [ -n "$(cat ./packageinfo | grep platform=zynq.ap_soc_cont_1)" ]
then
	echo "Firmware supports Zynq AP_SOC_CONT 1 platform"
	echo "    -> proceed"
else
	echo "Error: firmware does not support Zynq AP_SOC_CONT 1 platform"
	cd ../
	rm -r ./temp
	exit 0
fi

echo "Checking RAM size to determine sub-platform type"
MEM_TOTAL_KB=`grep MemTotal /proc/meminfo | grep -oe '\([0-9.]*\)'`
if [ $MEM_TOTAL_KB -eq 251692 ]
then
	echo "    "$MEM_TOTAL_KB" kB -> 1 DDR chip (AP_SOC_CONT_DDRx1 sub-platform)"

	if [ -n "$(cat ./packageinfo | grep sub_platform=zynq.ap_soc_cont_ddrx1)" ]
	then
		echo "    Firmware supports Zynq AP_SOC_CONT_DDRx1 sub-platform"
		echo "    -> proceed"
	else
		echo "    Error: firmware does not support Zynq AP_SOC_CONT_DDRx1 sub-platform"
		cd ../
		rm -r ./temp
		exit 0
	fi
else
	echo "    "$MEM_TOTAL_KB" kB -> 2 DDR chips (AP_SOC_CONT_DDRx2 sub-platform)"
	echo "    Assume all firmware packages support Zynq AP_SOC_CONT_DDRx2 sub-platform"
	echo "    -> proceed"
fi

#########################################################
# run janitor check scripts, abort if they report any   #
# incompatibility.sh if available and restart           #
#########################################################
for filename in ./janitor/*.sh
do
    if [ -f "$filename" ]
    then
        echo "Executing janitor check script $filename"
	    chmod 777 $filename
	    $filename
        rc=$?
	    rm $filename
        if [[ $rc != 0 ]]
        then
            echo "Update cancelled by janitor check script $filename"
            cd ../
            rm -r ./temp
            exit 0
        fi
    fi
done

#########################################################
# overwrite janitor.sh if available and restart         #
#########################################################
if [ -f ./janitor.sh ]
then
        echo "Replacing janitor.sh"
	mv ./janitor.sh ../janitor.sh
	chmod 777 ../janitor.sh
	../janitor.sh
	exit 0
fi

#########################################################
# clean previous firmware upgrade logs                  #
#########################################################
rm "/anapico/dev/fwupdate" 2> /dev/null

#########################################################
# execute shell script delivered with software          #
#########################################################
for filename in ./*.sh
do
    echo "Executing $filename"
	chmod 777 $filename
	$filename
	rm $filename
done


#########################################################
# clean up                                              #
#########################################################
cd ../
rm -r ./temp

#########################################################
# reboot                                                #
#########################################################
shutdown -r now

exit 0
