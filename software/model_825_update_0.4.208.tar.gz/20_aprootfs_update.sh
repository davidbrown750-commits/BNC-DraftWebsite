#!/bin/bash

#################################################
# add a temporary file system for /anapico/temp #
#################################################
echo "20_ap_rootfs_update.sh: add /anapico/temp"
APTEMPFSTAB=$(awk '/anapico/temp' /etc/fstab)

if [ -z "$APTEMPFSTAB" ]
then
	mkdir /anapico/temp
	echo 'tmpfs		/anapico/temp		tmpfs		defaults	0 0' >> /etc/fstab
	mount /anapico/temp
fi

APTEMPAVAHI=$(awk '/etc/avahi' /etc/fstab)

if [ -z "$APTEMPAVAHI" ]
then
	echo 'tmpfs		/etc/avahi/services		tmpfs		defaults	0 0' >> /etc/fstab
	mount /etc/avahi/services
fi



##########################################
# replace ifdown with simple script      # 
# executing ifconfig ONLY on eth0        #
##########################################
echo "20_ap_rootfs_update.sh: replace ifdown with script"
if [ -L "/sbin/ifdown" ]
then
	unlink /sbin/ifdown
	echo '#!/bin/sh' > /sbin/ifdown
	echo 'printf "\n turn off eth0 ... (ifdown replacement script)\n" ' >> /sbin/ifdown
	echo 'ifconfig eth0 down' >> /sbin/ifdown
	echo '' >> /sbin/ifdown
	chmod 777 /sbin/ifdown
fi

##########################################
# Link /etc/network/interfaces to        #
# /anapico/dev/conf/interfaces           #
##########################################
echo "20_ap_rootfs_update.sh: create interfaces symlink"
if [ ! -L "/etc/network/interfaces" ]
then
	rm /etc/network/interfaces
	ln -s /anapico/dev/conf/interfaces /etc/network/interfaces
fi

##########################################
# Create eth0_auto_conf if not available #
##########################################
echo "20_ap_rootfs_update.sh: Create eth0_auto_conf"
if [ ! -f "/anapico/dev/conf/eth0_auto_conf" ]
then 
	echo "auto eth0" > /anapico/dev/conf/eth0_auto_conf
	echo "iface eth0 inet dhcp" >>  /anapico/dev/conf/eth0_auto_conf
fi


