var running = false;
const ws = new WebSocket('ws://' + location.hostname + ':8080');
//const ws = new WebSocket('ws://10.10.5.50:8080');
ws.binaryType = 'arraybuffer';

var scpiTimeout;

var errorCounter = 0;

var commandQueue = [];
var answerReceived = false;
var timedOut = false;

var idn = "";
var freq = 0;
var pow = 0;
var phas = 0;
var outpStat = 0;
var extFreq = 0;
var lock = 0;
var refSour = "";
var refOutp = "";
var refOutpFreq = 0;
var ip = "";
var subn = "";
var gate = "";
var dhcp = "";
var pulmPer = 0;
var pulmPWid = 0;
var pulmSour = "";
var modStat = 0;
var alcHold = 0;

var currentChannel = "1";

var specificStatusCodeMappings = {
    '1000': 'Normal Closure',
    '1001': 'Going Away',
    '1002': 'Protocol Error',
    '1003': 'Unsupported Data',
    '1004': '(For future)',
    '1005': 'No Status Received',
    '1006': 'Abnormal Closure: Check if an other client is connected.',
    '1007': 'Invalid frame payload data',
    '1008': 'Policy Violation',
    '1009': 'Message too big',
    '1010': 'Missing Extension',
    '1011': 'Internal Error',
    '1012': 'Service Restart',
    '1013': 'Try Again Later',
    '1014': 'Bad Gateway',
    '1015': 'TLS Handshake'
};

var waiting = false;

var recieved = false;

var currentResponse = "";

var closed = false;

ws.onclose = (event) => {
    if (event.wasClean) {
        postMessage("Disconnected;");
    } else {
        postMessage("Close;Disconnected: " + event.code + " - " + specificStatusCodeMappings[event.code]);
    }
    closed = true;
    console.log('disconnected');
    ws.close();
}

ws.onerror = (e) => {
    errorCounter++;
    if (errorCounter === 5) {
        ws.close();
    }
}

ws.addEventListener("message", e => {
    waiting = false;
    var decoder = new TextDecoder('UTF-8');
    var data = decoder.decode(e.data);
    data.trim();
    recieved = true;
    if ((data + "").startsWith("QRY")) {
        postMessage(lastCommand + ";" + data);
    } else if (lastCommand === "*IDN?") {
        if (data !== idn) {
            idn = data;
            postMessage(lastCommand + ";" + idn);
        }
    } else if (lastCommand === "FREQ?") {
        if (parseInt(data) !== freq) {
            freq = parseFloat(data);
            postMessage(lastCommand + ";" + freq);
        }
    } else if (lastCommand === "OUTP:STAT?") {
        if (parseInt(data) !== outpStat) {
            outpStat = parseFloat(data);
            postMessage(lastCommand + ";" + outpStat);
        }
    } else if (lastCommand === "FREQ") {
        lastCommand = "FREQ?";
    } else if (lastCommand === "OUTP:STAT") {
        lastCommand = "OUTP:STAT?";
    } else if (lastCommand === "POW") {
        lastCommand = "POW?";
    } else if (lastCommand === "POW?") {
        if (parseInt(data) !== pow) {
            pow = parseFloat(data);
            postMessage(lastCommand + ";" + pow);
        }
    } else if (lastCommand === "PHAS") {
        lastCommand = "PHAS?";
    } else if (lastCommand === "PHAS?") {
        if (parseInt(data) !== phas) {
            phas = parseFloat(data);
            postMessage(lastCommand + ";" + phas);
        }
    } else if (lastCommand === "ROSC:EXT:FREQ?") {
        if (parseInt(data) !== extFreq) {
            extFreq = parseFloat(data);
            postMessage(lastCommand + ";" + extFreq);
        }
    } else if (lastCommand === "ROSC:LOCK?") {
        if (data !== lock) {
            lock = data;
            postMessage(lastCommand + ";" + lock);
        }
    } else if (lastCommand === "ROSC:SOUR?") {
        if (data !== refSour) {
            refSour = data;
            postMessage(lastCommand + ";" + refSour);
        }
    } else if (lastCommand === "ROSC:OUTP?") {
        if (data !== refOutp) {
            refOutp = data;
            postMessage(lastCommand + ";" + refOutp);
        }
    } else if (lastCommand === "ROSC:OUTP:FREQ?") {
        if (data !== refOutpFreq) {
            refOutpFreq = data;
            postMessage(lastCommand + ";" + refOutpFreq);
        }
    } else if (lastCommand === "SYST:COMM:LAN:IP?") {
        if (data !== ip) {
            ip = data;
            postMessage(lastCommand + ";" + ip);
        }
    } else if (lastCommand === "SYST:COMM:LAN:SUBN?") {
        if (data !== subn) {
            subn = data;
            postMessage(lastCommand + ";" + subn);
        }
    } else if (lastCommand === "SYST:COMM:LAN:GATE?") {
        if (data !== gate) {
            gate = data;
            postMessage(lastCommand + ";" + gate);
        }
    } else if (lastCommand === "SYST:COMM:LAN:CONF?") {
        if (data !== dhcp) {
            dhcp = data;
            postMessage(lastCommand + ";" + dhcp);
        }
    } else if (lastCommand === "PULM:INT:PER?") {
        if (Number.parseFloat(data).toFixed(10) !== pulmPer) {
            pulmPer = Number.parseFloat(data).toFixed(10);
            postMessage(lastCommand + ";" + pulmPer);
        }
    } else if (lastCommand === "PULM:INT:PWID?") {
        if (Number.parseFloat(data).toFixed(10) !== pulmPWid) {
            pulmPWid = Number.parseFloat(data).toFixed(10);
            postMessage(lastCommand + ";" + pulmPWid);
        }
    } else if (lastCommand === "PULM:SOUR?") {
        if (data !== pulmSour) {
            pulmSour = data;
            postMessage(lastCommand + ";" + pulmSour);
        }
    } else if (lastCommand === "PULM:STAT?") {
        if (data != modStat) {
            modStat = parseInt(data);
            postMessage(lastCommand + ";" + modStat);
        }
    } else if (lastCommand === "POW:ALC:HOLD?") {
        if (data != alcHold) {
            alcHold = parseInt(data);
            postMessage(lastCommand + ";" + alcHold);
        }
    } else if (lastCommand.startsWith("RESET")) {
        postMessage(lastCommand.replace("RESET:", "") + ";" + data);
    } else if (lastCommand.includes("MAX") || lastCommand.includes("MIN")) {
        postMessage(lastCommand + ";" + parseFloat(data));
    } else {
        postMessage(lastCommand + ";" + data);
    }
    answerReceived = true;
    if (lastCommand.includes("?") && !lastCommand.includes("QRY") && !lastCommand.includes("MIN") && !lastCommand.includes("MAX")) {
        commandQueue.push(lastCommand);
    }

    clearTimeout(scpiTimeout);

    sendNextCommand();

});

ws.onopen = () => {
    console.log('connected');
    commandQueue.push("FREQ?MAX");
    commandQueue.push("POW?MAX");
    commandQueue.push("ROSC:EXT:FREQ?MAX");
    commandQueue.push("POW?MIN");
    commandQueue.push("ROSC:EXT:FREQ?MIN");
    commandQueue.push("FREQ?MIN");
    commandQueue.push("SEL 1");
    commandQueue.push("PULM:INT:PER?MAX");
    commandQueue.push("PULM:INT:PER?MIN");
    commandQueue.push("PULM:INT:PWID?MAX");
    commandQueue.push("PULM:INT:PWID?MIN");
    sendNextCommand();
    readData();
}

onclose = () => {
    console.log('closing...');
    ws.close();
}

onmessage = (e) => {
    if (e.data === "Refresh") {
        readData();
    } else if (e.data === "ResetSystemSettings") {
        resetSystemSettings();
    } else if (e.data.startsWith("CHANNEL:")) {
        currentChannel = e.data.slice(-1);
        freq = 0;
        pow = 0;
        phas = 0;
        outpStat = 0;
        extFreq = 0;
        lock = 0;
        refSour = "";
        refOutp = "";
        refOutpFreq = 0;
        ip = "";
        subn = "";
        gate = "";
        dhcp = "";
        pulmPer = 0;
        pulmPWid = 0;
        pulmSour = "";
        modStat = 0;
        alcHold = 0;
        if (currentChannel !== "S") {
            commandQueue.push("SEL " + currentChannel);
        }
        readData();
    } else {
        var data = e.data;
        if (data.startsWith("PULM:INT:PER ")) {
            pulmPer = parseFloat(e.data.split(" ")[1].trim());
        } else if (data.startsWith("PULM:INT:PWID ")) {
            pulmPWid = parseFloat(e.data.split(" ")[1].trim());
        }
        var command = data.split(" ")[0];
        var replaced = false;
        for (var i = 0; i < commandQueue.length; i++) {
            if (commandQueue[i].includes(command + " ")) {
                commandQueue[i] = data;
                replaced = true;
            }
        }
        if (!replaced) {
            commandQueue.unshift(data);
        }
    }
}

function readData() {
    if (!closed) {
        waiting = true;
        commandQueue = []
        commandQueue.push("*IDN?");
        if (currentChannel === "S") {
            commandQueue.push("ROSC:EXT:FREQ?");
            commandQueue.push("ROSC:LOCK?");
            commandQueue.push("ROSC:SOUR?");
            commandQueue.push("ROSC:OUTP?");
            commandQueue.push("ROSC:OUTP:FREQ?");
            commandQueue.push("SYST:COMM:LAN:IP?");
            commandQueue.push("SYST:COMM:LAN:SUBN?");
            commandQueue.push("SYST:COMM:LAN:GATE?");
            commandQueue.push("SYST:COMM:LAN:CONF?");
        } else {
            commandQueue.push("FREQ?");
            commandQueue.push("POW?");
            commandQueue.push("OUTP:STAT?");
            commandQueue.push("PHAS?");
            commandQueue.push("PULM:INT:PER?");
            commandQueue.push("PULM:INT:PWID?");
            commandQueue.push("PULM:SOUR?");
            commandQueue.push("PULM:STAT?");
            commandQueue.push("POW:ALC:HOLD?");
        }
    }

}

function checkIfDataReturned() {
    if (waiting) {
        postMessage("Disconnected;");
        ws.close();
    }
}

function resetSystemSettings() {
    var encoder = new TextEncoder();
    setTimeout(function () { lastCommand = "RESET:SYST:COMM:LAN:IP?"; ws.send(encoder.encode("SYST:COMM:LAN:IP?\n")); }, 0);
    setTimeout(function () { lastCommand = "RESET:SYST:COMM:LAN:SUBN?"; ws.send(encoder.encode("SYST:COMM:LAN:SUBN?\n")); }, 30);
    setTimeout(function () { lastCommand = "RESET:SYST:COMM:LAN:GATE?"; ws.send(encoder.encode("SYST:COMM:LAN:GATE?\n")); }, 60);
    setTimeout(function () { lastCommand = "RESET:SYST:COMM:LAN:CONF?"; ws.send(encoder.encode("SYST:COMM:LAN:CONF?\n")); }, 90);
}

function sendCommand(command, timeout) {
    var encoder = new TextEncoder();
    lastCommand = command;
    command = command.trim().replace("QRY", "").replace("RESET:", "");
    ws.send(encoder.encode("SEL " + currentChannel + "\n"));
    ws.send(encoder.encode(command + "\n"));
    if (command.includes("?")) {
        scpiTimeout = setTimeout(() => {
            commandQueue.push(lastCommand);
            ws.send(encoder.encode("*CLS\n"));
            sendNextCommand();
        }, timeout);
    } else {
        sendNextCommand();
    }
}

function sendNextCommand() {
    var command = commandQueue.shift();
    sendCommand(command, 2000);
}