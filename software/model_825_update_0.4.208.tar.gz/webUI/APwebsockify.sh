#!/bin/sh
### BEGIN INIT INFO

#set -e

PATH=/sbin:/bin:/usr/sbin:/usr/bin
DESC="websocket to socket proxy"
NAME="APwebsockify"
DAEMON="/usr/bin/$NAME"
SCRIPTNAME=/etc/init.d/$NAME

# Gracefully exit if the package has been removed.
test -x $DAEMON || exit 0


#
#       Function that starts the daemon/service.
#
d_start() {
    # modprobe capability >/dev/null 2>&1 || true

    $DAEMON -D 8080 127.0.0.1:18 && return 0

}

#
#       Function that stops the daemon/service.
#
d_stop() {
    # echo "not implemented"
	killall $DAEMON
}

#
#       Function that reload the config file for the daemon/service.
#
d_reload() {
    echo "not implemented"
}

#
#       Function that check the status of the daemon/service.
#
d_status() {
    echo "not implemented"
}

case "$1" in
    start)
        echo "Starting $DESC" "$NAME"
        d_start
        ;;
    stop)
        echo "Stopping $DESC" "$NAME"
        d_stop
        ;;
    reload)
        echo "Reloading services for $DESC" "$NAME"
        d_reload
        ;;
    restart|force-reload)
        echo "Restarting $DESC" "$NAME"
        # $DAEMON -c && d_stop
        d_start
        ;;
    status)
        d_status
	;;
    *)
        echo "Usage: $SCRIPTNAME {start|stop|restart|force-reload|reload}" >&2
        exit 1
        ;;
esac

exit 0
