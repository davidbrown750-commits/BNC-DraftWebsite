#!/bin/sh

#############################################
# Add/Update web user interface             #
#############################################
echo "Adding webUI support"
tar -xzf webUI.tgz
cp -rf webUI/usr/bin/* /usr/bin/
chmod 777 /usr/bin/AP_websockify
chmod 777 /usr/bin/openssl
cp -rf webUI/usr/lib/* /usr/lib/
mkdir /etc/ssl
cp -rf webUI/etc/ssl /etc/ssl/

cp -f webUI/AP_websockify.sh /etc/init.d/
ln -s /etc/init.d/AP_websockify.sh /etc/rc5.d/S59AP_websockify

# if [ -z "$(grep 'AP_websockify' /etc/inetd.conf)" ]  
# then
#   cp webUI/inetd.conf /etc/inetd.conf
# fi

# mkdir /anapico/temp/www/
# mkdir /anapico/dev/www/
cp -rf webUI/www/* /anapico/dev/www/


if [ -f "/anapico/dev/fw_info" ]
then
	. /anapico/dev/fw_info
	sed -i 's/let companyName = \"AnaPico AG\"\;/let companyName = \"'"$MANUFACTURER"'\"\;/g' /anapico/dev/www/branding.js
	sed -i 's+let companyUrl = \"https://www.anapico.com/\"\;+let companyUrl = \"'"$URL"'\"\;+g' /anapico/dev/www/branding.js
	sed -i 's/let logoFileName = \"img\/logoAP.png\"\;/let logoFileName = \"'"img\/$LOGO"'\"\;/g' /anapico/dev/www/branding.js
	sed -i 's/let companyEMailAdress = \"support@anapico.com\"\;/let companyEMailAdress = \"\"\;/g' /anapico/dev/www/branding.js
fi



rm -rf webUI

echo "Added webUI support"

