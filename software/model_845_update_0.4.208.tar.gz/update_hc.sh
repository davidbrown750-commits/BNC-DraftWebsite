#!/bin/sh
echo "Front panel update"

# Load newest kernel module
echo "Front panel update: loading newest driver (kernel module)..."
rmmod /lib/modules/ap_hc_driver.ko
insmod /lib/modules/ap_hc_driver.ko
gunzip ./update_hc.bin.gz 
chmod 0777 ./update_hc.bin

# Find installed front panel and upload firmware
snstr=$(cat /anapico/dev/sn)
if [ ${snstr:4:1} == "2" ]
then
	echo "Front panel type: HC AT91, uploading firmware"
	if [ -f ./hc.hex ]
	then
		echo "Front panel firmware update for HC AT91"
		./update_hc.bin ./hc.hex /dev/aphc
		rm ./hc.hex
	else
		echo "Front panel firmware not available, skipping update"
	fi
elif [ ${snstr:4:1} == "3" ]
then
	echo "Front panel type: Touch panel STM, uploading internal flash image"
	if [ -f ./tp_stm_qspi.bin.gz ]
	then
		# Upload image
		gunzip tp_stm_qspi.bin.gz
		gunzip STM32F7_QSPI_RamLoader.bin.gz
		./update_hc.bin ./tp_stm_qspi.bin /dev/aphc stm_qspildr ./STM32F7_QSPI_RamLoader.bin
		rm ./tp_stm_qspi.bin
		rm ./STM32F7_QSPI_RamLoader.bin
	else
		echo "Front panel internal flash image not available, skipping update"
	fi
	echo "Front panel type: Touch panel STM, uploading internal flash image"
	if [ -f ./tp_stm_flash.bin.gz ]
	then
		# Upload image, preserve flash sector 1 (used as EEPROM)
		gunzip tp_stm_flash.bin.gz
		./update_hc.bin ./tp_stm_flash.bin /dev/aphc stm keeps1
		rm ./tp_stm_flash.bin
	else
		echo "Front panel internal flash image not available, skipping update"
	fi
elif [ ${snstr:4:1} == "4" ]
then
    echo "Front panel type: HC STM, uploading firmware"
	if [ -f ./hc_stm_flash.bin.gz ]
	then
		# Upload firmware, preserve flash sector 1 (used as EEPROM)
		gunzip hc_stm_flash.bin.gz
		./update_hc.bin ./hc_stm_flash.bin /dev/aphc stm keeps1
		rm ./hc_stm_flash.bin
	else
		echo "Front panel firmware not available, skipping update"
	fi
else
    echo "Front panel not installed, skipping firmware update"
fi
echo "Front panel update done"
cd $(pwd)

