#!/bin/sh

##########################################
# update FS FPGA configuration           #
##########################################

configStorageDir="/anapico/fpga"
fpgaConfigStorage="/anapico/fpga/mars_ax3_top.bin"

snstr=$(cat /anapico/dev/sn)
if [ ${snstr:5:1} == "4" ] || [ ${snstr:5:1} == "A" ] || [ ${snstr:5:1} == "B" ] || [ ${snstr:5:1} == "C" ]
then
    echo "FS FPGA update: option FS installed"
	fpgaConfig="./mars_ax3_top.bin"
	if [ -f $fpgaConfig.gz ]
	then
		    echo "    -> Loading newest generic IO driver (kernel module)..."
		    rmmod /lib/modules/ap_generic_io.ko
		    insmod /lib/modules/ap_generic_io.ko
		    echo "    -> Updating FS FPGA"
			gunzip ./update_fs_fpga.bin.gz
		    chmod 0777 ./update_fs_fpga.bin
		    mkdir -p $configStorageDir
			gunzip $fpgaConfig.gz
		    cp $fpgaConfig $fpgaConfigStorage
		    ./update_fs_fpga.bin $fpgaConfig
		    rm $fpgaConfig
	else
		echo "    -> error: FPGA configuration file not found ($fpgaConfig)"
	fi
	echo "    done (FS FPGA update)"
else
    echo "FS FPGA update: option FS not installed, nothing to do"
fi



