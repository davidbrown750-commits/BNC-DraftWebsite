DEVICE="MODEL_835-6"
# Insert device name here: DEVICE="DEVICE_NAME"
# makepackage.sh will do that automatically
#------------------------------------------------------------------------------------------#

echo "update.sh: terminate firmware"
killall $DEVICE
killall $(cat /etc/rc5.d/S61ap_run)
killall $DEVICE
killall $(cat /etc/rc5.d/S61ap_run)
sleep 1

##########################################
# check kernel module init script        #
##########################################
#if [ ! -f /etc/rc5.d/S60ap_modules ]
#then
#	touch /etc/rc5.d/S60ap_modules
#fi
#mv /etc/rc5.d/S60ap_modules /S60ap_modules
#grep -v ap_timer_driver.ko /S60ap_modules > /etc/rc5.d/S60ap_modules
#mv /etc/rc5.d/S60ap_modules /S60ap_modules
#grep -v ap_ssc_pulm.ko /S60ap_modules > /etc/rc5.d/S60ap_modules
#rm /S60ap_modules

##########################################
# remove obsolete kernel modules         #
##########################################
echo "update.sh: remove obsolete kernel modules"
#mv /etc/rc5.d/S60ap_modules /S60ap_modules
#grep -v ap_timer_driver.ko /S60ap_modules > /etc/rc5.d/S60ap_modules
rm /lib/modules/ap_timer_driver.ko
#mv /etc/rc5.d/S60ap_modules /S60ap_modules
#grep -v ap_ssc_pulm.ko /S60ap_modules > /etc/rc5.d/S60ap_modules
rm /lib/modules/ap_ssc_pulm.ko
#rm /S60ap_modules

##########################################
# update all kernel modules              #
##########################################
echo "update.sh: install or update kernel modules"
echo "#!/bin/sh" > /etc/rc5.d/S60ap_modules
for module_name in *.ko
do
	# if no old version available on system, add to rc5.d/S60ap_modules
	#if [ ! -e /lib/modules/$module_name ]
	#then
		if [ $module_name == "g_usbtmc.ko" ]
		then
			echo "insmod /lib/modules/$module_name serial_number="'$(cat /anapico/dev/sn)' >> /etc/rc5.d/S60ap_modules
		elif [ $module_name == "gpib.ko" ]
		then
			echo 'snstr=$(cat /anapico/dev/sn)' >> /etc/rc5.d/S60ap_modules
			echo 'if [ ${snstr:11:1} == "0" ]' >> /etc/rc5.d/S60ap_modules
			echo 'then' >> /etc/rc5.d/S60ap_modules
			echo '    echo "No GPIB module installed, skipping driver loading"' >> /etc/rc5.d/S60ap_modules
			echo 'else' >> /etc/rc5.d/S60ap_modules
			echo '    echo "Loading GPIB module driver"' >> /etc/rc5.d/S60ap_modules
			echo '    insmod /lib/modules/gpib.ko address=$(cat /anapico/dev/gpib)' >> /etc/rc5.d/S60ap_modules
			echo 'fi' >> /etc/rc5.d/S60ap_modules
			#echo "insmod /lib/modules/$module_name address="'$(cat /anapico/dev/gpib)' >> /etc/rc5.d/S60ap_modules
		else
			echo "insmod /lib/modules/$module_name" >> /etc/rc5.d/S60ap_modules
		fi
	#fi
	mv $module_name /lib/modules/$module_name
	#insmod /lib/modules/$module_name
done;
chmod 777 /etc/rc5.d/S60ap_modules

#------------------------------------------------------------------------------------------#

##########################################
# check firmware init / fallback script  #
##########################################
echo "update.sh: check firmware init / fallback script"
if [ ! -f /etc/rc5.d/S61ap_run ]
then
	touch /etc/rc5.d/S61ap_run
	chmod 777 /etc/rc5.d/S61ap_run
fi
if [ ! -f /etc/rc5.d/S62ap_fallback ]
then
	touch /etc/rc5.d/S62ap_fallback
	chmod 777 /etc/rc5.d/S62ap_fallback
fi


##########################################
# update firmware                        #
##########################################
echo "update.sh: write firmware loader script"
if [ -e ./$DEVICE.gz ]
then
	# always write the new binary to the start up script
	echo $DEVICE > /etc/rc5.d/S61ap_run
	#killall $DEVICE
	#sleep 1s
	gunzip ./$DEVICE.gz
	mv ./$DEVICE /bin/$DEVICE

	# Write fallback firmware loader script
	echo "#!/bin/sh" > /etc/rc5.d/S62ap_fallback
	echo 'if [ -e /media/ram/ap_framework_status ]' >> /etc/rc5.d/S62ap_fallback
	echo 'then' >> /etc/rc5.d/S62ap_fallback
	echo '    echo /media/ram/ap_framework_status exists' >> /etc/rc5.d/S62ap_fallback
	echo '    if [ $(cat /media/ram/ap_framework_status) != "exit_success" ]' >> /etc/rc5.d/S62ap_fallback
	echo '    then' >> /etc/rc5.d/S62ap_fallback
	echo '        echo framework running or exited with failure' >> /etc/rc5.d/S62ap_fallback
	echo "        $DEVICE -f" >> /etc/rc5.d/S62ap_fallback
	echo '    else' >> /etc/rc5.d/S62ap_fallback
	echo '        echo framework exited with success' >> /etc/rc5.d/S62ap_fallback
	echo '    fi' >> /etc/rc5.d/S62ap_fallback
	echo 'else' >> /etc/rc5.d/S62ap_fallback
	echo '    echo /media/ram/ap_framework_status missing' >> /etc/rc5.d/S62ap_fallback
	echo '    echo no framework status information available' >> /etc/rc5.d/S62ap_fallback
	echo 'fi' >> /etc/rc5.d/S62ap_fallback
fi

#------------------------------------------------------------------------------------------#

##########################################
# check anapico partition                #
##########################################
echo "update.sh: check AnaPico partition"
if [ ! -d /anapico/dev ]
then
	mkdir /anapico/dev
fi	
if [ ! -f /anapico/dev/gpib ]
then
	echo 1 > /anapico/dev/gpib
fi

#------------------------------------------------------------------------------------------#

##########################################
# write all *.csv scripts to /anapico    #
##########################################
echo "update.sh: copy data tables"
for file_name in *.csv
do
	mv $file_name /anapico/dev/$file_name
done;

#------------------------------------------------------------------------------------------#

##########################################
# overwrite linux kernel                 #
##########################################
echo "update.sh: kernel update"
if [ -e ./uImage_ecc1_bchecc4 ]
then 
    if [ "$(cat /proc/mtd | grep mtd4)" == "mtd4: 00200000 00020000 \"linux\"" ]
    then
        echo "Found kernel partition - 1 bit ECC NAND flash"
        #if [ "$(uname -a)" == "Linux instr0 2.6.33 #58 PREEMPT Tue May 12 15:05:59 CEST 2015 armv5tejl unknown" ]
	if [ "$(uname -mrspv)" == "Linux 2.6.33 #58 PREEMPT Tue May 12 15:05:59 CEST 2015 armv5tejl unknown" ]
        then
            echo "Skipped - kernel is up to date"
        else
            cp ./uImage_ecc1_bchecc4 /boot/uImage_ecc1_bchecc4
            if [ -e /boot/uImage_ecc1_bchecc4 ]
            then
                echo "Erasing kernel partition (1 bit ECC) - uImage_ecc1_bchecc4"
                flash_eraseall /dev/mtd4
                echo "Writing kernel partition (1 bit ECC) - uImage_ecc1_bchecc4"
                nandwrite -p /dev/mtd4 /boot/uImage_ecc1_bchecc4
                echo "Done"
            else
                echo "Failed - couldn't copy uImage_ecc1_bchecc4 to /boot/uImage_ecc1_bchecc4"
            fi
        fi
    elif [ "$(cat /proc/mtd | grep mtd4)" == "mtd4: 00200000 00020000 \"linux_bch\"" ]
    then
        echo "Found kernel partition - 4 bit BCH ECC NAND flash"
        #if [ "$(uname -a)" == "Linux instr0 2.6.33 #58 PREEMPT Tue May 12 15:05:59 CEST 2015 armv5tejl unknown" ]
	if [ "$(uname -mrspv)" == "Linux 2.6.33 #58 PREEMPT Tue May 12 15:05:59 CEST 2015 armv5tejl unknown" ]
        then
            echo "Skipped - kernel is up to date"
        else
            cp ./uImage_ecc1_bchecc4 /boot/uImage_ecc1_bchecc4
            if [ -e /boot/uImage_ecc1_bchecc4 ]
            then
                echo "Erasing kernel partition (4 bit BCH ECC) - uImage_ecc1_bchecc4"
                flash_eraseall /dev/mtd4
                echo "Writing kernel partition (4 bit BCH ECC) - uImage_ecc1_bchecc4"
                nandwrite -p /dev/mtd4 /boot/uImage_ecc1_bchecc4
                echo "Done"
            else
                echo "Failed - couldn't copy uImage_ecc1_bchecc4 to /boot/uImage_ecc1_bchecc4"
            fi
        fi
    else
        echo "Failed - kernel partition not found"
    fi
elif [ -e ./uImage ]
then 
    if [ "$(cat /proc/mtd | grep mtd4)" == "mtd4: 00200000 00020000 \"linux\"" ]
    then
        echo "Found kernel partition - 1 bit ECC NAND flash"
        #if [ "$(uname -a)" == "Linux instr0 2.6.33 #8 PREEMPT Mon May 9 17:00:09 CEST 2011 armv5tejl unknown" ]
	if [ "$(uname -mrspv)" == "Linux 2.6.33 #8 PREEMPT Mon May 9 17:00:09 CEST 2011 armv5tejl unknown" ]
        then
            echo "Skipped - kernel is up to date"
        else
            cp ./uImage /boot/uImage
            if [ -e /boot/uImage ]
            then
                echo "Erasing kernel partition (1 bit ECC) - uImage"
                flash_eraseall /dev/mtd4
                echo "Writing kernel partition (1 bit ECC) - uImage"
                nandwrite -p /dev/mtd4 /boot/uImage
                echo "Done"
            else
                echo "Failed - couldn't copy uImage to /boot/uImage"
            fi
        fi
    elif [ "$(cat /proc/mtd | grep mtd4)" == "mtd4: 00200000 00020000 \"linux_bch\"" ]
    then
        echo "Found kernel partition - 4 bit BCH ECC NAND flash"
        #if [ "$(uname -a)" == "Linux instr0 2.6.33 #35 PREEMPT Tue Nov 26 09:14:35 CET 2013 armv5tejl unknown" ]
	if [ "$(uname -mrspv)" == "Linux 2.6.33 #35 PREEMPT Tue Nov 26 09:14:35 CET 2013 armv5tejl unknown" ]
        then
            echo "Skipped - kernel is up to date"
        else
            cp ./uImage_bch /boot/uImage_bch
            if [ -e /boot/uImage_bch ]
            then
                echo "Erasing kernel partition (4 bit BCH ECC) - uImage"
                flash_eraseall /dev/mtd4
                echo "Writing kernel partition (4 bit BCH ECC) - uImage"
                nandwrite -p /dev/mtd4 /boot/uImage_bch
                echo "Done"
            else
                echo "Failed - couldn't copy uImage_bch to /boot/uImage_bch"
            fi
        fi
    else
        echo "Failed - kernel partition not found"
    fi
else
    echo "Skipped - package does not contain a kernel update"
fi
