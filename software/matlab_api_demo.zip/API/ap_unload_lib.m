function ap_unload_lib()
    if libisloaded( 'ap_comm_lib' ) == true
        unloadlibrary( 'ap_comm_lib' );
    end
end