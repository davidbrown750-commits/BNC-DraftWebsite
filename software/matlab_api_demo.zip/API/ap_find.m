function [str] = ap_find(find_itf)
% AP_FIND  Finds connected Anapico devices (LAN, USB and GPIB).
%   STR = ap_find(FIND_ITF) returns a string containing all devices found.
% 
%   STR contains the devices delimited by ';', and device information
%   delimited by ':'. Example:
%   'APSIN4010:161-212300010-0224:192.168.1.55;APPH20G:223-036315901-0252:USB-340-0A1000006-000;'
%   The last substring ('192.168.1.55' or 'USB-340-0A1000006-000') is an address string that can
%   be passed to AP_OPEN.
%
%   FIND_ITF defines the interfaces to be checked. Pass 'LAN' for LAN connection, 'USB' for USB
%   connection, 'GPIB' for GPIB connection (VISA must be loaded for GPIB to be available).
%   Multiple interfaces can be checked by concatenating the strings by an delimiter (',', ':', ';').
%
%   Examples:
%   STR = ap_find('LAN') finds devices connected to the LAN interface only.
%   STR = ap_find('LAN,USB,GPIB') finds devices connected to any interface.

	AP_COMM_IFACE_LAN = 1;
	AP_COMM_IFACE_USB = 16;
	AP_COMM_IFACE_VISA_GPIB	= 512;
	findItfMask = 0;
	if isempty(strfind(lower(find_itf), 'lan')) == 0
		findItfMask = findItfMask + AP_COMM_IFACE_LAN;
	end
	if isempty(strfind(lower(find_itf), 'usb')) == 0
		findItfMask = findItfMask + AP_COMM_IFACE_USB;
	end
	if isempty(strfind(lower(find_itf), 'gpib')) == 0
		findItfMask = findItfMask + AP_COMM_IFACE_VISA_GPIB;
	end
    bufSize = 2048;
    buf = blanks(bufSize);    % allocate memory for response
    [retv, buf] = calllib('ap_comm_lib', 'ap_comm_find', ...
                         libpointer('cstring',buf), 2000, bufSize, 0, findItfMask); %#ok<ASGLU>
	str = buf;
end