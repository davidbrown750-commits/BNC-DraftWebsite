function [socket_id] = ap_open(ipaddr, port)
    [retv, buf, socket_id] = calllib( 'ap_comm_lib', 'ap_comm_open', ...
                         libpointer('cstring', ipaddr), 2000, 0); %#ok<ASGLU>
end