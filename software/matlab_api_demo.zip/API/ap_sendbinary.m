function [status] = ap_sendbinary( sock_id, filename )
    status = calllib( 'ap_lan_lib', 'ap_sock_sendbinary', sock_id, libpointer('cstring',filename) );
end