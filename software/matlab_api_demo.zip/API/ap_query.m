function [answer] = ap_query(socket_id, command)     
    ap_puts(socket_id, command);
    answer = ap_gets(socket_id);