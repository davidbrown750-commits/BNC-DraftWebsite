function [status] = ap_receivebinary( sock_id, filename )
    %status = calllib( 'ap_comm_lib', 'ap_receivebinary', sock_id, libpointer('cstring',filename) );
    status = calllib( 'ap_comm_lib', 'ap_comm_readBlockFile', sock_id, '', libpointer('cstring',filename) );
end                                  
