function ap_load_lib()
	if libisloaded('ap_comm_lib') == false
        if strcmp(computer('arch'),'win32')==1
			loadlibrary('ap_comm_lib', 'ap_comm_lib.h');
		else
            loadlibrary('ap_comm_lib_64', 'ap_comm_lib.h', 'alias', 'ap_comm_lib');
        end
	end
end
