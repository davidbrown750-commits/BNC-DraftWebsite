function ap_free_visa()
    calllib('ap_comm_lib', 'ap_comm_freeVisa'); %#ok<ASGLU>
end