function ap_puts(sock_id, str)
   calllib('ap_comm_lib', 'ap_comm_puts', sock_id, ...
            libpointer('cstring',str), size(str,2), 0);
end
    