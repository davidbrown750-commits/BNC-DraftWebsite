function [] = apsin_set_tmo_s( sock_id, tmo )
    calllib( 'ap_comm_lib', 'ap_comm_setTmoMs', sock_id, tmo*1000 );
end
