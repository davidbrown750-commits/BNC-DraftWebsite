function [retv] = ap_load_visa()
    [retv] = calllib('ap_comm_lib', 'ap_comm_loadVisa'); %#ok<ASGLU>
end