function ap_close( sock_id )
    calllib( 'ap_comm_lib', 'ap_comm_close', sock_id );
end