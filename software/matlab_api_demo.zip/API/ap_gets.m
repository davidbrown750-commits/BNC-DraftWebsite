% Read data from APSIN device
function [str] = ap_gets(sock_id)
    bufSize = 2048;
    buf = blanks(bufSize);    % allocate memory for response
    [retv, buf, retc] = calllib('ap_comm_lib', 'ap_comm_gets', sock_id, ...
                      libpointer('cstring',buf), bufSize, 0); %#ok<ASGLU>
    str = buf;
end