clc;
path(path,'API');
ap_load_lib();
ap_load_visa()

ip = input('Please enter IP: ', 's');
if isempty(ip), ip = '192.168.1.38'; end

fprintf('\nConnecting to device %s\n', ip);
sock_id = ap_open(ip, 18);
fprintf(' -> sock_id: %d\n\n', sock_id);

fprintf('Send query "*IDN?"\n');
result = ap_query(sock_id, sprintf('*IDN?\n'));
fprintf(' -> "%s"\n\n', result);

fprintf('Send command "FREQ 1000000"\n\n');
ap_puts( sock_id, sprintf( 'FREQ 10000000\n') );

fprintf('Disconnecting\n');
ap_close(sock_id);

ap_free_visa()
ap_unload_lib();

