AnaPico LAN API Example

This Matlab example shows how to:
    - Connect to an Anapico device
    - Receive query answers from an Anapico device: get the "*IDN?" device id string
    - Send commands to an Anapico device: set frequency
    
All the Matlab code is located in "demo.m". The API is located in the "/API" folder.

