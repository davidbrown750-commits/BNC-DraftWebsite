#This script reads an SCPI Script and send the command to the instrument.
#In case of query it shows the output returned by instrument


##################################################################################################################

FilePath = "C:\Program Files (x86)\Active Technologies\EXPERT RIDER AWG 4000\SCPI\SampleScripts\SampleTimer.txt"
Instrument_Addr = 'TCPIP0::ARB-RIDER::inst0::INSTR'

##################################################################################################################


import visa

try:
    #Search the VISA instrument
    rm = visa.ResourceManager()

    #Connect with th AWG (insert the AWG name)
    AWG = rm.open_resource(Instrument_Addr)

    #Set the VISA timeout
    AWG.timeout = 60000 #ms, it is 60s

    #Identify the instrument
    print("You are connected to the instrument:\n",AWG.query("*IDN?"))


    #Open the SCPI file
    try:
        FileSCPI = open(FilePath,"r")
    except Exception:
        print ("File Error");


    #Send command line to the AWG
    Line = FileSCPI.readline()
    while Line != "":
        if (Line.find("?") < 0) :
            #Command
            AWG.write(Line)
        else :
            #Query
            print("QUERY: " + Line)
            print(AWG.query(Line))
        Line = FileSCPI.readline()

    #Close file
    FileSCPI.close()

    #Query for errors
    print("Errors:")
    err = AWG.query("SYST:ERR?")
    print (err)
    while (err.find("No error") < 0) :
        err = AWG.query('SYST:ERR?')
        print (err)                   
  
    #Close the VISA resources
    AWG.close()
    rm.close()

except Exception as e:
    print("Error: instrument communication: ",e)


print ("End of SCPI script")
input("Press enter to exit")
