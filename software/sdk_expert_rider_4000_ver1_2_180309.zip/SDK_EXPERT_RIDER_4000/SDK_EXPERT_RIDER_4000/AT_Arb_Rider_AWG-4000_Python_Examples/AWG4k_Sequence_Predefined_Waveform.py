#This script set the AWG sequencer with 2 predefined waveforms for each channels.
#On channel 1 it generate continuously 5 Triangular wave and 4 Sine wave
#On channel 2 it generate continuously 5 Sine wave and 4 Triangular wave


####################################################################################

Instrument_Addr = 'TCPIP0::ARB-RIDER::inst0::INSTR'

####################################################################################


import visa

try:
    #Search the VISA instrument
    rm = visa.ResourceManager()

    #Connect with th AWG (insert the AWG name)
    AWG = rm.open_resource(Instrument_Addr)

    #Set the VISA timeout
    AWG.timeout = 30000 #ms, it is 30s

    #Identify the instrument
    print("You are connected to the instrument:\n",AWG.query("*IDN?"))

    #Reset the instrument
    AWG.write("*RST")

    #Set the functionality
    AWG.write("AWGControl:CONFigure:SEQuencer:MODE SIN")
    AWG.write("AWGControl:CHANnel:FUNCTionality ARB,NONE")

    #Set the run mode and the sequence length
    AWG.write("AWGControl:RMODe SEQ")
    AWG.write("SEQuence:CHANnel1:LENGth 2")
    
    #Set the waveform for the channel 1
    AWG.write('SEQuence:CHANnel1:ELEMent1:WAVeform "Triangle_2048_P"')
    AWG.write('SEQuence:CHANnel1:ELEMent2:WAVeform "Sine_2048_P"')

    #Set the waveform for the channel 2
    AWG.write('SEQuence:CHANnel2:ELEMent1:WAVeform "Sine_2048_P"')
    AWG.write('SEQuence:CHANnel2:ELEMent2:WAVeform "Triangle_2048_P"')

    #Set the number of repetitions
    AWG.write("SEQuence:CHANnel:ELEM1:REP 5")
    AWG.write("SEQuence:CHANnel:ELEM2:REP 4")

    #Set the Go To
    AWG.write("SEQuence:CHANnel:ELEM1:GOTO 2")
    AWG.write("SEQuence:CHANnel:ELEM2:GOTO 1")

    #Update data and settings and start the generation
    AWG.write("AWGControl:UPDATEdata")
    AWG.write("AWGControl:RUN")

    #Query for errors until it receives: "0,No error"
    print("Errors:")
    err = AWG.query("SYST:ERR?")
    print (err)
    while (err.find("No error") < 0) :
        err = AWG.query('SYST:ERR?')
        print (err)                   
  
    #Close the VISA resources
    AWG.close()
    rm.close()

except Exception:
    print("Error: instrument communication")


input("Press enter to exit")
