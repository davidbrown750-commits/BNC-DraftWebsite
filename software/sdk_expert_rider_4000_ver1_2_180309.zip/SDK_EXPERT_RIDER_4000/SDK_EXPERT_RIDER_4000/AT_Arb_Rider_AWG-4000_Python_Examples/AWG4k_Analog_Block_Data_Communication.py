#This script generates an increasing ramp, then send it to the AWG using the Binary Block.
#You can select the Number of Point (SampleNum), the Amplitude and the Offset.
#The signal is the same for the 2 channels.


###############################################################################################

#Parameters
Instrument_Addr = "TCPIP0::ARB-RIDER::inst0::INSTR"
Amplitude = 5
Offset = -2.5
SampleNum = 2048

###############################################################################################


import visa

#Create a Ramp Waveform
Samples = []
i=0;
while (i<SampleNum) :
    Samples.append((Amplitude * i / SampleNum) + Offset)
    i=i+1


try:
    #Search the VISA instrument
    rm = visa.ResourceManager()

    #Connect with th AWG (insert the AWG name)
    AWG = rm.open_resource(Instrument_Addr)

    #Set the VISA timeout
    AWG.timeout = 60000 #ms, it is 60s

    #Identify the instrument
    print("You are connected to the instrument:\n",AWG.query("*IDN?"))

    #Reset the instrument
    AWG.write("*RST")

    #Set the functionality
    AWG.write("AWGControl:CONFigure:SEQuencer:MODE SIN")
    AWG.write("AWGControl:CHANnel:FUNCTionality ARB,NONE")

    #Set the run mode and the sequence length
    AWG.write("AWGControl:RMODe CONT")
    AWG.write('SEQuence:LENGth 1')

    AWG.write("WLISt:WAVeform:DELete ALL")
    
    #Create a new Waveform
    strCmd = 'WLISt:WAVeform:NEW "TestWfm",' + str(SampleNum)
    AWG.write(strCmd)

    #Send analog waveform
    strCmd = 'WLISt:WAVeform:DATA "TestWfm",0,' + str(SampleNum) + ','
    AWG.write_binary_values(strCmd, Samples, datatype='f', is_big_endian=False)

    #Assign the waveform to channels
    AWG.write('SOURCE1:WAVeform "TestWfm"')
    AWG.write('SOURCE2:WAVeform "TestWfm"')
    
    #Start the AWG
    AWG.write("AWGC:UPDATE")
    AWG.write("AWGC:RUN")

    #Query for errors
    print("Errors:")
    err = AWG.query("SYST:ERR?")
    print (err)
    while (err.find("No error") < 0) :
        err = AWG.query('SYST:ERR?')
        print (err)                   
  
    #Close the VISA resources
    AWG.close()
    rm.close()


except Exception as e:
    print("Error: instrument communication: ",e)


input("Press enter to exit")
