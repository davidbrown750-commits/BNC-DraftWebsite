The scripts contain commands like the following one:

WLIS:WAV:DATA "wave1",0,128,"An128.bin"

Before sending the command, it is necessary to replace the "An128.bin" with the binary data contained inside the .bin file. 