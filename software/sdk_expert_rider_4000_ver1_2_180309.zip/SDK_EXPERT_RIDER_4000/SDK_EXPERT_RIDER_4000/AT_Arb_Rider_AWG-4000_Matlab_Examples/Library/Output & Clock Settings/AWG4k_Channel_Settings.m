function [] = AWG4k_Channel_Settings(obj,Channel_Number,Output_Type,Amplitude_Scale,Offset,Vocm,Skew)
%[]=AWG4k_Channel_Settings(obj,Channel_Number,Output_Type,Amplitude_Scale,Offset,Vocm,Skew);
%
%This function sets the Analog Channel parameters:
%- obj: VISA object.
%- Channel_Number: 1 or 2 depending on the channel to apply the settings.
%- Output_Type: DCD for direct DAC, DCA for amplified, AC for AC coupling.
%- Amplitude Scale [%]: set the amplitude multiplier in percentage.
%- Offset [V]: set the offset level.
%- Vocm [V]: set the common mode voltage level.
%- Skew [s]: set the skew of the analog channel.
%
%Example: AWG4k_Channel_Settings(obj,1,'DCA',100,0,1,400e-12);

%set the Output Type
cmd=sprintf('SOURce%d:OUTputType %s',Channel_Number,Output_Type);
fprintf(obj,'%s',cmd);

%set the Amplitude Scale
cmd=sprintf('SOURce%d:AMPlitudeScale %f',Channel_Number,Amplitude_Scale);
fprintf(obj,'%s',cmd);

%Set the Offset level
cmd=sprintf('SOURce%d:OFFSet %f',Channel_Number,Offset);
fprintf(obj,'%s',cmd);

%Set the Common Voltage level
cmd=sprintf('SOURce%d:VOCM %f',Channel_Number,Vocm);
fprintf(obj, '%s',cmd);

%Set the channel Skew
cmd=sprintf('SOURce%d:SKEW %e',Channel_Number,Skew);
fprintf(obj, '%s',cmd);

end