function [] = AWG4k_Sampling_Rate(obj,Sampling_Clock)
%[]=AWG4k_Sampling_Rate(obj,Sampling_Clock);
%
%This function enables or disables the Analog Channel. Before execute this
%function the channel must be configured. The parameters are:
%- obj: VISA object.
%- Sampling_Clock [Hz]: Sampling Rate from internal clock.
%
%Example: AWG4k_Sampling_Rate(obj,2.5e9);

%set the Sampling Rate
cmd=sprintf('TIMING:SAMPLEFReq %e',Sampling_Clock);
fprintf(obj, '%s',cmd);

end