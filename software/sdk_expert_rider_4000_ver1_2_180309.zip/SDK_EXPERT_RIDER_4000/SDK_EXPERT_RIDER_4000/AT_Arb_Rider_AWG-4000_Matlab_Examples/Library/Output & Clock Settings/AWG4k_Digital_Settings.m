function [] = AWG4k_Digital_Settings(obj,Channel_Number,State,Digital_Amplitude,Skew)
%[]=AWG4k_Digital_Settings(obj,Channel_Number,State,Digital_Amplitude,Skew);
%
%This function sets the Digital Channel parameters:
%- obj: VISA object.
%- Channel_Number: 1 or 2 depending on the channel to apply the settings.
%- State: 0 Disables the digital channels, 1 Enables the digital channels.
%- Digital_Amplitude [V]: voltage of the digital High Level.
%- Skew [s]: set the Skew of the digital channel.
%
%Example: AWG4k_Digital_Settings(obj,2,1,2.5,0);

if State>0 %apply settings only if the channel is enabled
    
    %enable the digital channels
    cmd=sprintf('SOURce%d:DIGital:STATe ON',Channel_Number);
    fprintf(obj,'%s',cmd);
    
    %set the High Level
    cmd=sprintf('SOURce%d:DIGital:VOLTage %f',Channel_Number,Digital_Amplitude);
    fprintf(obj,'%s',cmd);
    
    %set the digital channel Skew
    cmd=sprintf('SOURce%d:DIGital:SKEW %e',Channel_Number,Skew);
    fprintf(obj,'%s',cmd);
else
    
    %disable the digital channels
    cmd=sprintf('SOURce%d:DIGital:STATe OFF',Channel_Number);
    fprintf(obj,'%s',cmd);
end

end

