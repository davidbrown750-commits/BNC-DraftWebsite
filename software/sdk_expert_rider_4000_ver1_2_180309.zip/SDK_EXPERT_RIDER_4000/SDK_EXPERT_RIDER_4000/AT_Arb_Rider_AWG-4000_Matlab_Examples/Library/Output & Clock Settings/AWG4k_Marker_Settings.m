function [] = AWG4k_Marker_Settings(obj,Channel_Number,Marker_Selection,Marker_Type,Marker_Amplitude,Skew)
%[]=AWG4k_Marker_Settings(obj,Channel_Number,Marker_Selection,Marker_Type,Marker_Amplitude,Skew);
%
%This function sets the Marker parameters:
%- obj: VISA object.
%- Channel_Number: 1 or 2 depending on the channel to apply the settings.
%- Marker_Selection: LOW, HIGH, LINE. Low sets the marker to 0V, High sets
%the marker to high level, Line set the marker to read digital data.
%- Marker_Type: ANALOG, DIGITAL. Analog activates the marker out SMA
%connector on the front panel, Digital outputs the marker signal through
%digital pod.
%- Marker_Amplitude [V]: voltage of the digital High Level on the SMA
%connector on front panel.
%- Skew [s]: set the Skew of the marker.
%
%Example: AWG4k_Marker_Settings(obj,1,'Line','Analog',2,8e-10);


%set the marker Source
cmd=sprintf('SOURce%d:MARKer:VOLTage:SELection %s',Channel_Number,Marker_Selection);
fprintf(obj, '%s',cmd);

%set the marker Type
cmd=sprintf('SOURce%d:MARKer:TYPe %s',Channel_Number,Marker_Type);
fprintf(obj,'%s',cmd);

%Set the marker High Level
cmd=sprintf('SOURce%d:MARKer:VOLTage %f',Channel_Number,Marker_Amplitude);
fprintf(obj,'%s',cmd);

%Set the marker Skew
cmd=sprintf('SOURce%d:MARKer:SKEW %e',Channel_Number,Skew);
fprintf(obj, '%s',cmd);

end

