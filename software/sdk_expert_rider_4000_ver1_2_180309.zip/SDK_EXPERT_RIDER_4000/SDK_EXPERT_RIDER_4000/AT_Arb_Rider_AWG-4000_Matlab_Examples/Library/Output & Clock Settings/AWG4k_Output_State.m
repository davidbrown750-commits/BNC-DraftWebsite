function [] = AWG4k_Output_State(obj,Channel_Number,State)
%[]=AWG4k_Output_State(obj,Channel_Number,State);
%
%This function enables or disables the Analog Channel. Before execute this
%function the channel must be configured. The parameters are:
%- obj: VISA object.
%- Channel_Number: 1 or 2 depending on the channel to apply the settings.
%- State: 0 or 1. 0 Disables the analog channel, 1 Enables the analog
%channel.
%
%Example: AWG4k_Output_State(obj,1,1);

%enable or disable the analog channel
if State>0
    cmd=sprintf('OUTPut%d ON',Channel_Number);
else
    cmd=sprintf('OUTPut%d OFF',Channel_Number);
end

fprintf(obj, '%s',cmd);

end