function [Waveform_List] = AWG4k_Read_Waveform_List(obj)
%[Waveform_List]=AWG4k_Read_Waveform_List(obj);
%
%This function reads the waveform list of the AWG and return a cell array
%with the available waveform. The only parameter is:
%- obj: VISA object.
%
%Example: WFM_List = AWG4k_Read_Waveform_List(obj);

%send the query
fprintf(obj, 'WLISt:LIST?');

%read the response
message=fscanf(obj);

%split the string on comma and delete spaces
Waveform_List=strtrim(strsplit(message,','));

end