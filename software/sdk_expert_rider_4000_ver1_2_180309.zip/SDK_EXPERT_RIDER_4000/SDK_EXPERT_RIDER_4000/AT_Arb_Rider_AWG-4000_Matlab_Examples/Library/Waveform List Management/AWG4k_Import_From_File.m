function [] = AWG4k_Import_From_File(obj,Waveform_Name,Waveform_File,Waveform_Type)
%[]=AWG4k_Import_From_File(obj,Waveform_Name,Waveform_File,Waveform_Type);
%
%This function imports a waveforms from text file. The parameters are:
%- obj: VISA object.
%- Waveform_Name: the name assigned to the waveform in the waveform list.
%- Waveform_File: the complete file path.
%- Waveform_Type: TXT or DIG. TXT for analog and mixed waveforms or DIG for
%digital ones.
%
%Example: AWG4k_Import_From_File(obj,'sine','C:\WaveImport\sine.txt','TXT')

cmd=sprintf('MMEMORY:IMPORT "%s","%s",%s',Waveform_Name,Waveform_File,Waveform_Type);
fprintf(obj, '%s',cmd);

end