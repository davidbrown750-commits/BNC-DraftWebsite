function [] = AWG4k_Save_Waveform_Into_Text_File(Analog_Waveform,Digital_Waveform,Type,File_Path,File_Name)
%[]=AWG4k_Save_Waveform_Into_Text_File(Analog_Waveform,Digital_Waveform,Type,File_Path,File_Name);
%
%This function saves a waveform into the filesystem. The parameters are:
%- obj: VISA object.
%- Analog_Waveform: an array of the samples, the value is the outputted
%voltage.
%- Digital_Waveform: a matrix with 8 or 16 colons of 0 and 1.
%- Type: Analog, Mixed or Digital.
%- File_Path: the path where save the waveform, (it must exist).
%- File_Name: the name assigned to the file, if it exits, it will be
%overwritten.
%Note: in mixed mode the length of the analog wfm and the length of the
%digital wfm must be the same.
%
%Note: the matrix dimension must be N_Samples x 1 for the analog waveform
%and N_Samples x 8 or N_Samples x 16 for the digital waveform.
%If 'LowSp' is selected the number of columns of the digital waveform must
%be a quarter of the number of columns of the analog waveform.
%If 'HighSp' is selected the number of columns of the digital waveform must
%be half the number of row of the analog waveform.
%
%Example:
%AWG4k_Save_Waveform_Into_Text_File(sine_2400,ones(2400,16),'Mixed',...
%   'C:\Matlab_Waveform\','Mixed_Sine.txt');

File_Path_Complete=strcat(File_Path,File_Name);
fileID=fopen(File_Path_Complete,'wt');

if strcmp(Type,'Analog')
    %write analog wave
    fprintf(fileID,'%f\n',Analog_Waveform);
end

if strcmp(Type,'Digital')
    %write digital wave
    [~,c]=size(Digital_Waveform);
    if c==8
        fprintf(fileID,'#0,#1,#2,#3,#4,#5,#6,#7\n');
        fprintf(fileID,'%d,%d,%d,%d,%d,%d,%d,%d\n',Digital_Waveform');
    end
    if c==16
        fprintf(fileID,'#0,#1,#2,#3,#4,#5,#6,#7,#8,#9,#10,#11,#12,#13,#14,#15\n');
        fprintf(fileID,'%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n',Digital_Waveform');
    end
    
end

if strcmp(Type,'Mixed')
    [~,c]=size(Digital_Waveform);
    Mixed_Waveform=[Analog_Waveform,Digital_Waveform];
    if c==8
        fprintf(fileID,'%f,%d,%d,%d,%d,%d,%d,%d,%d\n',Mixed_Waveform');
    end
    if c==16
         fprintf(fileID,'%f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n',Mixed_Waveform');
    end
end

fclose(fileID);

end

