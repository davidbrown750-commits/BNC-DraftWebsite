function [] = AWG4k_Delete_Waveform(obj,Waveform_Name)
%[]=AWG4k_Delete_Waveform(obj,Waveform_Name);
%
%This function deletes waveforms from the waveform list. The parameters
%are:
%- obj: VISA object.
%- Waveform_Name: the name of the waveform to delete (in quotes) or the
%word ALL (without quotes) to delete all the waveforms.
%
%Examples: AWG4k_Delete_Waveform(obj,'"sine_2048"');
%          AWG4k_Delete_Waveform(obj,'ALL');


cmd=sprintf('WLISt:WAVeform:DELete %s',Waveform_Name);
fprintf(obj, '%s',cmd);

end