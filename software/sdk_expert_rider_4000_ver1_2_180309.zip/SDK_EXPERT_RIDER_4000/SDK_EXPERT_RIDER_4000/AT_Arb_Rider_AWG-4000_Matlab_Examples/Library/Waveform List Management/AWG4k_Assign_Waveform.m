function [] = AWG4k_Assign_Waveform(obj,Channel,Waveform_Name)
%[]=AWG4k_Assign_Waveform(obj,Channel,Waveform_Name);
%
%This function assigns a waveform to a channel when the Run Mode is not
%Sequence. The parameters are:
%- obj: VISA object.
%- Channel: 1 or 2, define the channel to which assign the waveform.
%- Waveform_Name: the waveform to assign.
%
%Example: AWG4k_Assign_Waveform(obj,1,'sine_2048');


cmd=sprintf('SOURCE%d:WAVeform "%s"',Channel,Waveform_Name);
fprintf(obj, '%s',cmd);

end