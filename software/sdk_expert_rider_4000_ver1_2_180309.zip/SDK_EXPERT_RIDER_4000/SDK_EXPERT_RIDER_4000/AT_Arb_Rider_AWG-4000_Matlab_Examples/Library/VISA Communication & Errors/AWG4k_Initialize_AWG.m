function [] = AWG4k_Initialize_AWG(obj,Run_Mode,Digital_Option,Reset)
%[] = AWG4k_Initialize_AWG(obj,Run_Mode,Digital_Option,Reset)
%
%This function initializes the communication and allows to select the Run
%Mode. More, it sets the input and output buffer length at 5000 bytes and
%the communication timeout. The input parameters are:
%- obj: VISA object.
%- Run Mode: Continuous, Triggered, Gated, Sequence.
%- Digital_Option: HighSp for high speed, LowSp for low speed, None for no
%digital.
%- Reset: 0 or 1. If the value is positive the instrument will be reset.
%
%Example:
%obj = AWG4k_Initialize_AWG(obj,'Continuous','None',1);



%send the reset command
if Reset > 0
    fprintf(obj,'*RST');
end

%set the single sequencer mode
fprintf(obj,'AWGC:CONF:SEQ:MODE SIN');

%set the single digital option
fprintf(obj,'AWGC:CHAN:FUNCT ARBitrary,%s',Digital_Option);

%set the single run mode
fprintf(obj,'AWGC:RMODE %s',Run_Mode);

end

