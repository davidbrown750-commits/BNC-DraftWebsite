function [] = AWG4k_Close_Communication_AWG(obj,Dysplay_Error)
%[]=AWG4k_Close_Communication_AWG(obj,Dysplay_Error);
%
%This function queries for errors, then close the communication and delete
%the instrument object. The parameters are:
%- obj: VISA object.
%- Display_Error: 0 or 1. 1 displays error messages from AWG.
%
%Example: AWG4k_Close_Communication_AWG(obj,1);

AWG4k_System_Error(obj,Dysplay_Error);

%close the instrument object
fclose(obj);

%delete instrument object
delete(obj);

end

