function [obj] = AWG4k_Connect_AWG(Instr_Name,Timeout)
%[obj]=AWG4k_Connect_AWG(Instr_Name,Timeout);
%
%This function opens the communication. More, it sets the input and output
%buffer length at 5000 bytes and the communication timeout. The input
%parameters are:
%- Instr_Name: VISA instrument name.
%- Timeout [s]: the timeout of the VISA communication.
%
%The output parameters are:
%- obj: returns the VISA object.
%
%Example: obj = AWG4k_Connect_AWG('TCPIP0::ARB-RIDER::inst0::INSTR',100);


% Find a VISA-TCPIP object.
obj = instrfind('Type', 'visa-tcpip', 'RsrcName', Instr_Name);

% Create the VISA-TCPIP object if it does not exist
% otherwise use the object that was found.
if isempty(obj)
    obj = visa('NI', Instr_Name);
else
    fclose(obj);
    obj = obj(1);
end

%Set the buffers size at 70 Mbytes (before open)
obj.InputBufferSize=70e6;
obj.OutputBufferSize=70e6;

%Set the timeout (before open)
obj.Timeout=Timeout;

%Connect to instrument object, obj1.
fopen(obj);

end

