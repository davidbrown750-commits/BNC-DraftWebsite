function [] = AWG4k_Run_AWG(obj)
%[]=AWG4k_Run_AWG(obj);
%
%This function puts the AWG in Run state. The only parameter is:
%- obj: VISA object.
%
%Example: AWG4k_Run_AWG(obj);

fprintf(obj, 'AWGC:RUN');

end