function [] = AWG4k_Stop_AWG(obj)
%[]=AWG4k_Stop_AWG(obj);
%
%This function stops the AWG. The only parameter is:
%- obj: VISA object.
%
%Example: AWG4k_Stop_AWG(obj);

fprintf(obj, 'AWGC:STOP');

end
