function [] = AWG4k_Update_AWG(obj, type)
%[]=AWG4k_Update_AWG(obj);
%
%This function updates the Data, the Settings or both. The parameters are:
%- obj: VISA object.
%- type: SET for settings, DATA for data, ALL for both.
%
%Example: AWG4k_Update_AWG(obj, 'ALL');

cmd = sprintf('AWGC:UPDATE %s',type);
fprintf(obj, '%s',cmd);

end