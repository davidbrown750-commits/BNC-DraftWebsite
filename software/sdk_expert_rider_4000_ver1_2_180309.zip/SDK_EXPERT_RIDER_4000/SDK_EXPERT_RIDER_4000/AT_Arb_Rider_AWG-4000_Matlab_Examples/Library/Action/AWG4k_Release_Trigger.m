function [] = AWG4k_Release_Trigger(obj)
%[]=AWG4k_Release_Trigger(obj);
%
%This function releases the Trigger from software. The only parameter is:
%- obj: VISA object.
%
%Example: AWG4k_Release_Trigger(obj);

fprintf(obj, 'ABORt');

end