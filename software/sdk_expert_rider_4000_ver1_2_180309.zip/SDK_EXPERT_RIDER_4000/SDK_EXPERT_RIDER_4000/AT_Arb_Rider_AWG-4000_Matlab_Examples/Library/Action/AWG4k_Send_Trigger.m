function [] = AWG4k_Send_Trigger(obj)
%[]=AWG4k_Send_Trigger(obj);
%
%This function sends the software Trigger. The only parameter is:
%- obj: VISA object.
%
%Example: AWG4k_Send_Trigger(obj);

fprintf(obj, '*TRG');

end

