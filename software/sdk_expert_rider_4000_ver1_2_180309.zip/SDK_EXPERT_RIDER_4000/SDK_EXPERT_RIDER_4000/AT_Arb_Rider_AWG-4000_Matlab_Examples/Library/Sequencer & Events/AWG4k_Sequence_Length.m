function [] = AWG4k_Sequence_Length(obj,Seq_Length)
%[]=AWG4k_Sequence_Length(obj,Seq_Length);
%
%This function sets the length of the sequencer when the Run Mode is
%Sequence. The parameters are:
%- obj: VISA object.
%- Seq_length: length of the sequencer.
%
%Example: AWG4k_Sequence_Length(obj,4);


cmd=sprintf('SEQ:LENGth %d',Seq_Length);
fprintf(obj, '%s',cmd);


end

