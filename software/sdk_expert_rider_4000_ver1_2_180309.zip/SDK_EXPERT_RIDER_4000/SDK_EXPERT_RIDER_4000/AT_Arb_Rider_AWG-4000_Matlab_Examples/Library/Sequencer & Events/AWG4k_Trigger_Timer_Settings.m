function [] = AWG4k_Trigger_Timer_Settings(obj,Timer_Period,Trigger_Threshold)
%[]=AWG4k_Trigger_Timer_Settings(obj,Timer_Period,Trigger_Threshold);
%
%This function assign a waveform to a sequencer entry. The parameters are:
%- obj: VISA object.
%- Timer_Period [us]: the period of the timer.
%- Trigger_Threshold [V]: the threshold of the trigger in from the SMA
%connector on front panel.
%
%Example: AWG4k_Trigger_Timer_Settings(obj,1e3,1.5);


cmd=sprintf('EVENTS:TRIGINTIMERPeriod %e',Timer_Period);
fprintf(obj, '%s',cmd);

cmd=sprintf('EVENTS:TRIGINTHReshold %f',Trigger_Threshold);
fprintf(obj, '%s',cmd);

end