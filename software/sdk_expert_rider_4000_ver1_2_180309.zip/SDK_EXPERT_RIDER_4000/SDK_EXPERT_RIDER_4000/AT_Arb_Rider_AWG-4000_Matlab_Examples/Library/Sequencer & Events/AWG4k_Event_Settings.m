function [] = AWG4k_Event_Settings(obj,Event_Number,Operators,Sources)
%[]=AWG4k_Event_Settings(obj,Event_Number,Operators,Sources);
%
%This function set the parameter of the even trees, that are:
%- obj: VISA object.
%- Event_Number: the events are 7, from 0 to 6.
%- Operators: it is an Array of 3 elements that defines the three
%operators. You can choose the operators from the following list: AND, OR,
%XOR, NAND, NOR, XNOR.
%- Sources: it is an Array of 4 elements that defines the four sources. You
%can choose the sources from the following list: True, False, TrgIn, Timer,
%ForceTrigger, Marker1, NotTrgIn, NotTimer, NotForceTrigger.
%
%Example:
%AWG4k_Event_Settings(obj,0,{'AND','AND','XOR'},{'TRUE','TRUE','TIMER','TRGIN'});

%Set the operators
op_num=min(3,length(Operators));
for i=1:op_num
cmd=sprintf('ANALOGCHAN:EVENTS%d:OPER%d %s',Event_Number,i,Operators{i});
fprintf(obj, '%s',cmd);
end

%Set the sources
src_num=min(4,length(Sources));
for i=1:src_num
cmd=sprintf('ANALOGCHAN:EVENTS%d:SOURCE%d %s',Event_Number,i,Sources{i});
fprintf(obj, '%s',cmd);

end

end

