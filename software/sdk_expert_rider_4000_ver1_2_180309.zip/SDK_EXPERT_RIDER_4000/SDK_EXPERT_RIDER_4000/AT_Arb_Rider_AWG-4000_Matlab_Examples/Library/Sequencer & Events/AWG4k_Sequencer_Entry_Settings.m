function [] = AWG4k_Sequencer_Entry_Settings(obj,Entry_Number,Repetition,Go_To_Address,Wait_Event,Jump_Event,Jump_Address,Jump_Type)
%[]=AWG4k_Sequencer_Entry_Settings(obj,Entry_Number,Repetition,Go_To_Address,Wait_Event,Jump_Event,Jump_Address,Jump_Type);
%
%This function sets the parameters of a sequencer entry. The parameters are:
%- obj: VISA object.
%- Entry_Number: select the entry to apply the settings.
%- Repetition: can be a Number or the word INF, it controls how many time
%repeat the entry.
%- Go_To_Address: sets the next entry to reproduce.
%- Wait_Event: sets the event to verify before start the generation.
%- Jump_Event: sets the event to verify to jump to another entry.
%- Jump_Address: sets the destination of the jump.
%- Jump_Type: Async, Sync. It set the jump type.
%Note: the events are 7, from 0 to 6, if you write -1 in as event, it is
%mapped as NONE.
%
%Example: AWG4k_Sequencer_Entry_Settings(obj,1,'2',3,-1,-1,1,'Async');

%set the repetition number
cmd=sprintf('SEQ:ELEMent%d:REP %s',Entry_Number,Repetition);
fprintf(obj,'%s',cmd);

%set the Go To Address
cmd=sprintf('SEQ:ELEMent%d:GOTO %d',Entry_Number,Go_To_Address);
fprintf(obj,'%s',cmd);

%set the Wait Event
if(Wait_Event>=0)
    cmd=sprintf('SEQ:ELEMent%d:WAITEvent %d',Entry_Number,Wait_Event);
else
    cmd=sprintf('SEQ:ELEMent%d:WAITEvent NONE',Entry_Number);
end
fprintf(obj,'%s',cmd);

%set the jump mode to event
fprintf(obj, 'AWGControl:EVENt:JMODe EJUMp');

%set the Jump Event
if(Jump_Event>=0)
    cmd=sprintf('SEQ:ELEMent%d:JUMPEvent %d',Entry_Number,Jump_Event);
    fprintf(obj,'%s',cmd);
    
    %set the Jump Address
    cmd=sprintf('SEQ:ELEMent%d:JUMPAddr %d',Entry_Number,Jump_Address);
    fprintf(obj,'%s',cmd);

    %set the Jump Type
    cmd=sprintf('SEQ:ELEMent%d:JUMPType %s',Entry_Number,Jump_Type);
    fprintf(obj,'%s',cmd);
    
else
    cmd=sprintf('SEQ:ELEMent%d:JUMPEvent NONE',Entry_Number);
    fprintf(obj,'%s',cmd);
end

end

