function [] = AWG4k_Sequencer_Waveform(obj,Channel,Sequencer_Entry,Waveform_Name)
%[]=AWG4k_Sequencer_Waveform(obj,Channel,Sequencer_Entry,Waveform_Name);
%
%This function assign a waveform to a sequencer entry. The parameters are:
%- obj: VISA object.
%- Channel: the channel where output the waveform.
%- Sequencer_Entry: the position in the sequencer to be assigned to the
%waveform.
%- Waveform_Name: the name of the waveform in the waveform list.
%
%Note: the waveform must be present in the waveform list.
%
%Example: AWG4k_Sequencer_Waveform(obj,1,2,'Sine_2048_P');


cmd=sprintf('SEQuence:CHANnel%d:ELEMent%d:WAVeform "%s"',Channel,Sequencer_Entry,Waveform_Name);
fprintf(obj, '%s',cmd);

end