%In this example the system reads an SCPI script from a text file and
%sends the commands to the AWG. In case of queries it prints the query and
%the response.

%%

%Path of the file that contains SCPI script.
%Insert the path of the SCPI script file located into
%SDK_EXPERT_RIDER_4000\SCPI\SampleScript\
File_path='C:\Users\AT-LAB\Desktop\SDK_EXPERT_RIDER_4000\SCPI\SampleScripts\SampleTimer.txt';

%%

%Open the communication with the AWG
obj=AWG4k_Connect_AWG('TCPIP0::ARB-RIDER::inst0::INSTR',100);

%open the SCPI text file 
fileID = fopen(File_path,'r');

cmd = fgets(fileID);%Read the first line from SCPI script
while cmd ~= -1
    
    %submit the command line
    fprintf(obj,'%s',cmd);
    
    %if the string is a query, read the response.
    if ~isempty(strfind(cmd,'?'))
        message=fscanf(obj);
        fprintf('%s\t%s\n',cmd(1:end-2),message);% end-2 avoid the new line.
    end
    
    %read the next line from SCPI script
    cmd = fgets(fileID);
    
end
fclose(fileID);

%Close the communication with the instrument
AWG4k_Close_Communication_AWG(obj,1);