%This script shows the predefined waveforms and loads two waveform on each
%channel depending on the number assigned at the variables "Wfm_1_Ch1",
%"Wfm_1_Ch2", "Wfm_2_Ch1" and "Wfm_2_Ch2". The first number is the
%sequencer entry, the second one is the channel number.
%More it offers the controls about:
%- the type of output;
%- the voltage gain;
%- the offset level;
%- the common voltage level.
%
%Note: It is neccessary to choose waveform of the same length for the
%waveforms assigned to a sequencer entry.

%%

%Set the predefined waveform numbers for the entry 1 and 2 of the channel 1
Wfm_1_Ch1=7;
Wfm_2_Ch1=12;

%Set the predefined waveform numbers for the entry 1 and 2 of the channel 2
Wfm_1_Ch2=1;
Wfm_2_Ch2=9;

%Set the entry repetition number
Entry_1_Repetition='10';
Entry_2_Repetition='4';

%Set the output type:DCD, DCA, AC
Output_Type_Ch1='DCA';
Output_Type_Ch2='DCD';

%Output gain
Output_Gain_Ch1=200;
Output_Gain_Ch2=100;

%Output offset
Output_Offset_Ch1=0;
Output_Offset_Ch2=0.1;

%Output common voltage
Output_Common_Voltage_Ch1=1;
Output_Common_Voltage_Ch2=0;

%Insert the name of the instrument
InstrumentName = 'TCPIP0::ARB-RIDER::inst0::INSTR';

%%

%Connect to the AWG
obj=AWG4k_Connect_AWG(InstrumentName,100);

%Initialize AWG and select the continuous run mode
AWG4k_Initialize_AWG(obj,'sequence','NONE',1);

%Read and show the predefined waveform
Pred_Wfm = AWG4k_Read_Waveform_List(obj);
for i=1:1:length(Pred_Wfm)
    fprintf('%d %s\n',i,Pred_Wfm{i});
end

%Define the sequence length
AWG4k_Sequence_Length(obj,2);

%Assign a waveform to each channel
AWG4k_Sequencer_Waveform(obj,1,1,Pred_Wfm{Wfm_1_Ch1});
AWG4k_Sequencer_Waveform(obj,2,1,Pred_Wfm{Wfm_1_Ch2});

AWG4k_Sequencer_Waveform(obj,1,2,Pred_Wfm{Wfm_2_Ch1});
AWG4k_Sequencer_Waveform(obj,2,2,Pred_Wfm{Wfm_2_Ch2});

%Set the entry properties
AWG4k_Sequencer_Entry_Settings(obj,1,Entry_1_Repetition,2,-1,-1,1,'Async');
AWG4k_Sequencer_Entry_Settings(obj,2,Entry_2_Repetition,1,-1,-1,1,'Async');

%Set the channel properties
AWG4k_Channel_Settings(obj,1,Output_Type_Ch1,Output_Gain_Ch1,Output_Offset_Ch1,Output_Common_Voltage_Ch1,0);
AWG4k_Channel_Settings(obj,2,Output_Type_Ch2,Output_Gain_Ch2,Output_Offset_Ch2,Output_Common_Voltage_Ch2,0);

%Update and Run
AWG4k_Update_AWG(obj,'ALL');
AWG4k_Run_AWG(obj);

%Query for errors
AWG4k_System_Error(obj,1);

%Show dialog box to termite the waveform generation
q=questdlg('Stop AWG?','End generation','STOP','Cancel','Cancel');
if strcmp(q,'STOP')
    AWG4k_Stop_AWG(obj);
end

%Close the communication with the instrument
AWG4k_Close_Communication_AWG(obj,1);