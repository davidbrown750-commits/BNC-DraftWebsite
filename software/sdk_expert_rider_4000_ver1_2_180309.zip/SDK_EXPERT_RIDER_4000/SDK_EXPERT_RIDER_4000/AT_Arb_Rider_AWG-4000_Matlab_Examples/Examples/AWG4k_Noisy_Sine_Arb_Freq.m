%This example shows how to generate a noisy signal, adding white noise to
%waveform. On channel 1 there is the noisy sine waveform and on channel 2
%there is the noisy sine waveform.
%More it shows a way to produce an arbitrary frequency using an AWG
%avoiding the wrap around problem. The solution consists into calculate the
%number of samples that compose a period at a given sampling rate, then if
%it is not a integer number the waveform is repeated to reach an integer
%number of samples. Finally it calculates the least common multiple between
%the number of points and the granularity of the AWG.
%The tolerance controls the accuracy of the frequency, but a lower
%tolerance probably takes more AWG memory. The tolerance value is not
%directly linked with the frequency tolerance because after the
%rationalization, the number of samples is multiplied to satisfy the AWG
%granularity.

%%

%Waveform frequency [Hz]
Frequency = 12.38e6;

%Frequency tollerance
Tolerance=1e-3;

%Set the AWG sampling rate;
SamplingRate=2.5e9;

%Sine amplitude [Vpk]
Amplitude=1;

%Noise level into 50 Ohm [dBw]
NoisePwr=-30;

%Insert the name of the instrument
InstrumentName = 'TCPIP0::ARB-RIDER::inst0::INSTR';

%%

%Number of samples for a single cicle
NumPoints=SamplingRate/Frequency;

%Calculate the number of samples to have an integer number of cycles.
%The Numerator is the total number of samples, the denominator is the
%number of cycles.
[NumPointsTotal,NumCycle]=rat(NumPoints,Tolerance);

%Real syntetized frequency
RealFreq=SamplingRate*NumCycle/NumPointsTotal;
FrequencyErrorPpm=(Frequency-RealFreq)/Frequency*1e6;
fprintf('Syntetized frequency: %f\n',RealFreq);
fprintf('Frequency error: %f ppm\n',FrequencyErrorPpm);

%Search the least number of samples that satisfy the AWG granularity
if NumPointsTotal<320
    NumSamplesAWG=lcm(NumPointsTotal,64);
else
    NumSamplesAWG=lcm(NumPointsTotal,16);
end

%Define time vector
t = (0:1:NumSamplesAWG-1)';

%Create single sinewave
Waveform=single(sin(2*pi*1/NumPoints*t))*Amplitude;

%White noise generation
Noise=single(wgn(NumSamplesAWG,1,NoisePwr,50));

%Genrate 2 waveforms
NoisySine=(Waveform+Noise);
PureSine=Waveform;

%Connect to the AWG
obj=AWG4k_Connect_AWG(InstrumentName,100);

%Initialize AWG and select the continuous run mode
AWG4k_Initialize_AWG(obj,'Continuous','NONE',1);

%Load the waveforms into AWG memory
AWG4k_Send_Wfm_Binary_Block(obj,'NoisySine',0,NoisySine,0,'none');
AWG4k_Send_Wfm_Binary_Block(obj,'Sine',0,PureSine,0,'none');

%Assign the waveform at the two channels
AWG4k_Assign_Waveform(obj,1,'NoisySine');
AWG4k_Assign_Waveform(obj,2,'Sine');

%Set the sampling rate
AWG4k_Sampling_Rate(obj,SamplingRate);

%Start the generation
AWG4k_Update_AWG(obj,'ALL');
AWG4k_Run_AWG(obj);

%Query for system errors
AWG4k_System_Error(obj,1);

%Show dialog box to termite the waveform generation
q=questdlg('Stop AWG?','End generation','STOP','Cancel','Cancel');
if strcmp(q,'STOP')
    AWG4k_Stop_AWG(obj);
end

%Close the communication with the instrument
AWG4k_Close_Communication_AWG(obj,1);