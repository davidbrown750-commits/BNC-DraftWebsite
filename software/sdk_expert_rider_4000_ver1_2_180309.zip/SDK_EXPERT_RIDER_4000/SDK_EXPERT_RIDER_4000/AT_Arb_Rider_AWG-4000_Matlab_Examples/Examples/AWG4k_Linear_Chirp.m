%This example generates a linear chirp on the two channels. You can set the
%start and the stop frequencies, the sweep time, the sampling rate and the
%amplitude. More the marker generates a square wave with its rising edge on
%the start of the chirp.

%%

%Set the AWG sampling rate [S/s]
Sampling_rate=2.5*10^9;

%Set the amplitude [Vpk]
Amplitude=0.5;

%Set the amplitude of the marker [V]
Marker_Amplitude=2;

%Set start and stop frequencies [Hz]
f_start=10*10^6;
f_stop=60*10^6;

%Set the sweep time [s]
t_sweep=0.15e-3;

%Insert the name of the instrument
InstrumentName = 'TCPIP0::ARB-RIDER::inst0::INSTR';

%%

%Round the number of points at the nearest muultiple of 16
N_point=t_sweep*Sampling_rate;
resume=mod(N_point,16);
if resume~=0
    N_point_16=round(N_point/16)*16;
else
    N_point_16=N_point;
end

t_sweep_16=N_point_16/Sampling_rate;
t = 0:t_sweep_16/(N_point_16-1):t_sweep_16;

%Generate a square wave on the marker (the marker waveform is a quarter of
%the analog waveform because it is in low speed mode)
Marker=[[ones(1,N_point_16/8);zeros(15,N_point_16/8)],zeros(16,N_point_16/8)];

%Generate the chirp signal
ylin = chirp(t,f_start,t_sweep_16,f_stop)*Amplitude;

%Connect to AWG
obj=AWG4k_Connect_AWG(InstrumentName,100);

%Initialize AWG and select the continuous run mode
AWG4k_Initialize_AWG(obj,'Continuous','NONE',1);

%Load the waveform into AWG memory
AWG4k_Send_Wfm_Binary_Block(obj,'lin_chirp',0,ylin,Marker,'lowsp');

%Assign the waveform at the two channels
AWG4k_Assign_Waveform(obj,1,'lin_chirp');
AWG4k_Assign_Waveform(obj,2,'lin_chirp');

%Set the sampling rate
AWG4k_Sampling_Rate(obj,Sampling_rate);

%Set the marker parameters
AWG4k_Marker_Settings(obj,1,'Line','Analog',Marker_Amplitude,0);

%Start the generation
AWG4k_Update_AWG(obj,'ALL');
AWG4k_Run_AWG(obj);

%Query for errors
AWG4k_System_Error(obj,1);

%Show dialog box to termite the waveform generation
q=questdlg('Stop AWG?','End generation','STOP','Cancel','Cancel');
if strcmp(q,'STOP')
    AWG4k_Stop_AWG(obj);
end

%Close the communication with the instrument
AWG4k_Close_Communication_AWG(obj,1);