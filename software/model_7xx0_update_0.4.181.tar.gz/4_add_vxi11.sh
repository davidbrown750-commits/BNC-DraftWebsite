#!/bin/sh

#############################################
# Add VXI-11 support (fix LO interface bug, #
# install RPC portmapper and  RPC binaries  #
#############################################
echo "Adding VXI-11 support"
cp -r ./vxi11/rootfs/* /
opkg install ./vxi11/packages/glibc-utils_2.6.1-r15.1_armv5te.ipk
opkg install ./vxi11/packages/portmap_6.0-r3.1_armv5te.ipk
echo "Added VXI-11 support"

