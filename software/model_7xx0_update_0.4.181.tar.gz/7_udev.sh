#!/bin/sh

#############################################
# Re-adjust udev
# Udev spawned too many childs, that may
# lock the system
# Udev checked mtd* partitions, which won't
# work due to the filesystem installed
#############################################
echo "Re-adjusting udev"
cp -r ./udev/rootfs/* /
echo "Re-adjusted udev"

