#!/bin/sh

#############################################
# Add mDNS services for VX-11/LXI incl.     #
# httpd for identification file             #
#############################################
echo "Adding mDNS support"
tar -xzf mDNS.tgz
cp -fr mDNS/usr/sbin/* /usr/sbin/
cp -fr mDNS/usr/lib/* /usr/lib/
cp -fr mDNS/usr/share/* /usr/share/
cp -fr mDNS/lib/* /lib/
cp -fr mDNS/etc/* /etc/

cp -f mDNS/AP_generateAvahiServices /usr/sbin/AP_generateAvahiServices
chmod 777 /usr/sbin/AP_generateAvahiServices

ln -s /etc/init.d/httpd /etc/rc5.d/S57httpd
ln -s /etc/init.d/avahi-daemon /etc/rc5.d/S58avahi-daemon

cp -f mDNS/etc/init.d/hostname.sh /etc/init.d/
# overwrite if there is an original interface file with e.g. usb ehternet devices
if [ -n "$(grep 'usb' /etc/network/interfaces)" ]
then
   cat /anapico/dev/conf/lo_conf /anapico/dev/conf/eth0_dhcp_conf > /etc/network/interfaces
fi

if [ -z "$(grep 'hostname' /etc/network/interfaces)" ] &&  [ -n "$(grep 'dhcp' /etc/network/interfaces)" ]
then
   echo '    hostname $(hostname)' >> /etc/network/interfaces
fi

if [ -z "$(grep 'avahi' /etc/passwd)" ]  
then
   echo "avahi:x:500:500:Linux User,,,:/home/avahi:/bin/sh" >> /etc/passwd
   echo "avahi:x:500:" >> /etc/group
fi

mv -f mDNS/50default /etc/udhcpc.d/50default
mv -f mDNS/avahi-autoipd.action /etc/avahi/avahi-autoipd.action
mv -f mDNS/S59network_fix /etc/rc5.d/S59network_fix


mkdir /anapico/temp/www/
rm -rf /anapico/dev/www
mkdir /anapico/dev/www/


chmod 744 /anapico/dev/www
mkdir /anapico/dev/www/lxi
chmod 744 /anapico/dev/www/lxi

cp -fr mDNS/www/* /anapico/dev/www/

cp -f mDNS/http.service /anapico/dev/http.service

mv fw_info /anapico/dev/fw_info

echo "Added mDNS support"

