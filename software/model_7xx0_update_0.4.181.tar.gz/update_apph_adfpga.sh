#!/bin/sh -x

##########################################
# update APPH_ADFPGA configuration       #
##########################################

set -x # -x option causes each shell command to be printed before it is executed, which can be useful for debugging.

configStorageDir="/anapico/fpga"
fpgaConfigStorage="/anapico/fpga/fpga_config.bin"
softCoreStorage="/anapico/fpga/adfpga.srec"

snstr=$(cat /anapico/dev/sn)
if [ ${snstr:6:1} == "1" ] || [ ${snstr:6:1} == "2" ]
then
    echo "FPGA bitstream selection: APPH analog board <=2: LVDS counter"
	fpgaConfig="./fpga_config_0.4.58.bin.gz"
	softCore="./adfpga_0.4.58.srec.gz"
	adfpga_ver="1"
else
	if [ ${snstr:9:1} \< "6" ]
	then
    	echo "FPGA bitstream selection: Digitizer Version < 6: ADFPGA_1"
		fpgaConfig="./fpga_config.bin.gz"
		softCore="./adfpga.srec.gz"
		adfpga_ver="1"
	else
    	echo "FPGA bitstream selection: Digitizer Version >= 6: ADFPGA_2"
		fpgaConfig="./fpga_config_adfpga2.bin.gz"
		softCore="./adfpga2.srec.gz"
		adfpga_ver="2"
	fi
fi

if [ -f $fpgaConfig ]
then
    if [ -f $softCore ]
    then
        echo "Loading newest AP SPI and GPIO driver (kernel module)..."
        rmmod /lib/modules/apko.ko
        sleep 3 # Wait to make sure that there is enough time to remove the module        
		insmod /lib/modules/apko.ko
        echo "Copying Compressed Binaries .bin.gz and .srec.gz"
        chmod 0777 ./update_apph_adfpga.bin
        mkdir -p $configStorageDir
        cp $fpgaConfig "$fpgaConfigStorage.gz"
        cp $softCore "$softCoreStorage.gz"
		echo "Decompressing .bin and .srec"
		gzip -d -f "$fpgaConfigStorage.gz"
		gzip -d -f "$softCoreStorage.gz"
	    echo "Updating Flash"
        sleep 3 # Wait to make sure that there is enough time to decompress the gz files
        ./update_apph_adfpga.bin $adfpga_ver $fpgaConfigStorage $softCoreStorage
    else
        echo "Soft core file not found ($softCore)"
    fi
else
    echo "FPGA configuration file not found ($fpgaConfig)"
fi
echo "done (FPGA update)"

