#!/bin/sh

##########################################
# Copy xeno libs to the /lib/ path       #
##########################################
cp /usr/xenomai/lib/* /lib/

