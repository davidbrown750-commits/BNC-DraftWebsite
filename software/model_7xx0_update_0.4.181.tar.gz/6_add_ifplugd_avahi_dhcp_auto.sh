#!/bin/sh

#############################################
# Add ifplugd with avahi support
# Uninstall netplug
#############################################
echo "Adding DHCP / auto support and enabling faster boot for ifplugd with avahi"
cp -r ./ifplugd_avahi_dhcp_auto/rootfs/* /
echo "Added DHCP / auto support and enabled faster boot for ifplugd with avahi"
