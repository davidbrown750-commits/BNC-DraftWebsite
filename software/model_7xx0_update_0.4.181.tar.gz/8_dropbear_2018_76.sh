#!/bin/sh

#############################################
# Upgrade dropbear to fix known SSH
# vulnerabilities
#############################################
echo "Upgrade dropbear to version 2018.76 with CBC modes and 3DES disabled"
tar -xzf dropbear_2018_76.tgz
cp -r ./dropbear_2018_76/dropbearmulti /usr/sbin/dropbearmulti
chmod 0755 /usr/sbin/dropbearmulti
cp -r "./dropbear_2018_76/passwd" "/etc/passwd"
chmod 0644 "/etc/passwd"
echo "Upgraded dropbear to version 2018.76 with CBC modes and 3DES disabled"

