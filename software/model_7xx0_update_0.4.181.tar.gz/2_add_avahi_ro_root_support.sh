#!/bin/sh

#############################################
# Add ifplugd with avahi support
# Uninstall netplug
#############################################
echo "Adding avahi read-only root support"
rm -r /var/lib/avahi-autoipd
mkdir /var/volatile/avahi-autoipd
ln -s /var/volatile/avahi-autoipd /var/lib/avahi-autoipd
cp -r ./avahi_ro_root_support/rootfs/* /
echo "Added avahi read-only root support"

