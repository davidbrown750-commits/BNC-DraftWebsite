#!/bin/sh

#############################################
# Add ifplugd with avahi support
# Uninstall netplug
#############################################
echo "Installing ifplugd with avahi support"
tar -xzf ifplugd_avahi.tgz
cp -r ./ifplugd_avahi/rootfs/* /
echo "Removing netplug"
rm /etc/rcS.d/S41netplug
rm /sbin/netplugd
rm -r /etc/netplug
rm -r /etc/netplug.d
echo "Installed ifplugd with avahi support"

