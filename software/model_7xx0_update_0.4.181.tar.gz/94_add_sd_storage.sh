#!/bin/sh

#############################################
# Add scripts and setup for SD card storage
#############################################
echo "Add support for SD card storage"
tar -xzf sd_storage.tar.gz -C /

#cat >>/etc/fstab <<EOF
#
## AnaPico large flash storage (SD card)
#/dev/mmcblk0p1	/storage	auto		sync,noauto		0  0
#EOF
#
#echo >>/etc/udev/mount.blacklist /dev/mmcblk0p1

# Hotplug not supported yet, so we just use remount ro/rw like the other filesystems for now.
cat >>/etc/fstab <<EOF

# AnaPico large flash storage (SD card)
/dev/mmcblk0p1	/storage	auto		sync,ro			0  0
EOF

echo "Added support for SD card storage"
