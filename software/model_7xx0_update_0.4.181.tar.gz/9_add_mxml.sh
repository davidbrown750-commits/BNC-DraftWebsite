#!/bin/sh

#############################################
# Add MXML support for managing XML files #
#############################################
echo "Adding MXML support"
tar -xzf mxml.tgz
cp mxml/* /lib/
echo "Added MXML support"

