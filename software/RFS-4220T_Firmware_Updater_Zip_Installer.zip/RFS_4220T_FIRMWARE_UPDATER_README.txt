RFS-4220T Firmware Updater - Zip Installer
==========================================

How to install:

1. Right-click the ZIP and choose Extract All.
2. Open the extracted folder.
3. Double-click Install_RFS_4220T_Firmware_Updater.cmd.

The installer creates an RFS-4220T Firmware Updater shortcut on the desktop and
in the Berkeley Nucleonics Start Menu folder. It also creates an uninstall
shortcut in the Start Menu.

Do not run the installer from inside the ZIP preview window. The entire ZIP must
be extracted first.

Unit software requirement:

The RFS-4220T must contain the unit runtime that supports computer-initiated
firmware uploads. Development or service units still running the older
touchscreen-initiated updater need that runtime deployed once. After that one
runtime installation, every firmware update below is performed entirely from
the external computer; no unit button or touchscreen action is required.

How to update firmware:

1. Connect the computer to the RFS-4220T by LAN or USB-B.
2. Close the 4000 Series GUI or any other application controlling that unit.
3. Open RFS-4220T Firmware Updater.
4. Select the desired unit from the discovered-device list.
5. Browse to the released RFS-1220 .hex firmware file.
6. Press Update Firmware and keep the unit powered and connected until the
   progress bar reaches 100% and completion is reported.

The updater validates Intel HEX structure and checksums before transfer. It also
verifies the connected unit identity, transfers the file with SHA-256 checks,
and monitors programming and reconnection through completion.

Included files:

- RFS-4220T Firmware Updater.exe
- bnc_transparent.ico
- Install_RFS_4220T_Firmware_Updater.cmd
- RFS_4220T_FIRMWARE_UPDATER_README.txt
