@echo off
setlocal

set "INSTALL_PS1=%TEMP%\rfs_4220t_firmware_updater_install_%RANDOM%%RANDOM%.ps1"

> "%INSTALL_PS1%" echo $ErrorActionPreference = "Stop"
>> "%INSTALL_PS1%" echo $AppName = "RFS-4220T Firmware Updater"
>> "%INSTALL_PS1%" echo $Company = "Berkeley Nucleonics"
>> "%INSTALL_PS1%" echo $InstallDir = Join-Path $env:LOCALAPPDATA "$Company\RFS-4220T Firmware Updater"
>> "%INSTALL_PS1%" echo $SourceDir = "%~dp0"
>> "%INSTALL_PS1%" echo $ExeSource = Join-Path $SourceDir "RFS-4220T Firmware Updater.exe"
>> "%INSTALL_PS1%" echo $IconSource = Join-Path $SourceDir "bnc_transparent.ico"
>> "%INSTALL_PS1%" echo $ExeTarget = Join-Path $InstallDir "RFS-4220T Firmware Updater.exe"
>> "%INSTALL_PS1%" echo $IconTarget = Join-Path $InstallDir "bnc_transparent.ico"
>> "%INSTALL_PS1%" echo if (-not (Test-Path $ExeSource)) { throw "RFS-4220T Firmware Updater.exe was not found. Extract the entire ZIP before installing." }
>> "%INSTALL_PS1%" echo New-Item -ItemType Directory -Force -Path $InstallDir ^| Out-Null
>> "%INSTALL_PS1%" echo Copy-Item -Force -Path $ExeSource -Destination $ExeTarget
>> "%INSTALL_PS1%" echo if (Test-Path $IconSource) { Copy-Item -Force -Path $IconSource -Destination $IconTarget }
>> "%INSTALL_PS1%" echo $Shell = New-Object -ComObject WScript.Shell
>> "%INSTALL_PS1%" echo $Desktop = [Environment]::GetFolderPath("Desktop")
>> "%INSTALL_PS1%" echo $DesktopShortcut = Join-Path $Desktop "$AppName.lnk"
>> "%INSTALL_PS1%" echo $Shortcut = $Shell.CreateShortcut($DesktopShortcut)
>> "%INSTALL_PS1%" echo $Shortcut.TargetPath = $ExeTarget
>> "%INSTALL_PS1%" echo $Shortcut.WorkingDirectory = $InstallDir
>> "%INSTALL_PS1%" echo $Shortcut.Description = "Berkeley Nucleonics RFS-4220T Firmware Updater"
>> "%INSTALL_PS1%" echo if (Test-Path $IconTarget) { $Shortcut.IconLocation = $IconTarget }
>> "%INSTALL_PS1%" echo $Shortcut.Save()
>> "%INSTALL_PS1%" echo $StartMenu = Join-Path ([Environment]::GetFolderPath("StartMenu")) "Programs\$Company"
>> "%INSTALL_PS1%" echo New-Item -ItemType Directory -Force -Path $StartMenu ^| Out-Null
>> "%INSTALL_PS1%" echo $StartShortcut = Join-Path $StartMenu "$AppName.lnk"
>> "%INSTALL_PS1%" echo $Shortcut = $Shell.CreateShortcut($StartShortcut)
>> "%INSTALL_PS1%" echo $Shortcut.TargetPath = $ExeTarget
>> "%INSTALL_PS1%" echo $Shortcut.WorkingDirectory = $InstallDir
>> "%INSTALL_PS1%" echo $Shortcut.Description = "Berkeley Nucleonics RFS-4220T Firmware Updater"
>> "%INSTALL_PS1%" echo if (Test-Path $IconTarget) { $Shortcut.IconLocation = $IconTarget }
>> "%INSTALL_PS1%" echo $Shortcut.Save()
>> "%INSTALL_PS1%" echo $UninstallScript = Join-Path $InstallDir "Uninstall RFS-4220T Firmware Updater.ps1"
>> "%INSTALL_PS1%" echo Set-Content -Encoding UTF8 -Path $UninstallScript -Value '$ErrorActionPreference = "SilentlyContinue"'
>> "%INSTALL_PS1%" echo Add-Content -Encoding UTF8 -Path $UninstallScript -Value ('Remove-Item -Force "' + $DesktopShortcut + '"')
>> "%INSTALL_PS1%" echo Add-Content -Encoding UTF8 -Path $UninstallScript -Value ('Remove-Item -Force "' + $StartShortcut + '"')
>> "%INSTALL_PS1%" echo Add-Content -Encoding UTF8 -Path $UninstallScript -Value ('Remove-Item -Recurse -Force "' + $InstallDir + '"')
>> "%INSTALL_PS1%" echo $UninstallShortcut = Join-Path $StartMenu "Uninstall RFS-4220T Firmware Updater.lnk"
>> "%INSTALL_PS1%" echo $Shortcut = $Shell.CreateShortcut($UninstallShortcut)
>> "%INSTALL_PS1%" echo $Shortcut.TargetPath = "powershell.exe"
>> "%INSTALL_PS1%" echo $Shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$UninstallScript`""
>> "%INSTALL_PS1%" echo $Shortcut.WorkingDirectory = $InstallDir
>> "%INSTALL_PS1%" echo $Shortcut.Description = "Uninstall Berkeley Nucleonics RFS-4220T Firmware Updater"
>> "%INSTALL_PS1%" echo $Shortcut.Save()
>> "%INSTALL_PS1%" echo Write-Host "$AppName installed successfully."
>> "%INSTALL_PS1%" echo Write-Host "A shortcut was created on the desktop."

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%INSTALL_PS1%"
set "INSTALL_RESULT=%ERRORLEVEL%"
del "%INSTALL_PS1%" >nul 2>nul

if not "%INSTALL_RESULT%"=="0" (
    echo.
    echo Installation failed.
    pause
    exit /b %INSTALL_RESULT%
)

echo.
echo Installation complete. The updater shortcut is on the desktop.
pause
exit /b 0

